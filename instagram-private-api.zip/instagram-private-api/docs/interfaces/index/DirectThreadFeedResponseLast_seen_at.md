[instagram-private-api](../../README.md) / [index](../../modules/index.md) / DirectThreadFeedResponseLast_seen_at

# Interface: DirectThreadFeedResponseLast\_seen\_at

[index](../../modules/index.md).DirectThreadFeedResponseLast_seen_at

## Table of contents

### Properties

- [300687565](DirectThreadFeedResponseLast_seen_at.md#300687565)

## Properties

### 300687565

• **300687565**: [`DirectThreadFeedResponse300687565`](DirectThreadFeedResponse300687565.md)

#### Defined in

[src/responses/direct-thread.feed.response.ts:58](https://github.com/Nerixyz/instagram-private-api/blob/0e0721c/src/responses/direct-thread.feed.response.ts#L58)
