[instagram-private-api](../../README.md) / [index](../../modules/index.md) / IgtvSearchResponseHashtag

# Interface: IgtvSearchResponseHashtag

[index](../../modules/index.md).IgtvSearchResponseHashtag

## Table of contents

### Properties

- [id](IgtvSearchResponseHashtag.md#id)
- [name](IgtvSearchResponseHashtag.md#name)

## Properties

### id

• **id**: `string`

#### Defined in

[src/responses/igtv.search.response.ts:41](https://github.com/Nerixyz/instagram-private-api/blob/0e0721c/src/responses/igtv.search.response.ts#L41)

___

### name

• **name**: `string`

#### Defined in

[src/responses/igtv.search.response.ts:42](https://github.com/Nerixyz/instagram-private-api/blob/0e0721c/src/responses/igtv.search.response.ts#L42)
