[instagram-private-api](../../README.md) / [index](../../modules/index.md) / LikedFeedResponseImage_versions2

# Interface: LikedFeedResponseImage\_versions2

[index](../../modules/index.md).LikedFeedResponseImage_versions2

## Table of contents

### Properties

- [candidates](LikedFeedResponseImage_versions2.md#candidates)

## Properties

### candidates

• **candidates**: [`LikedFeedResponseCandidatesItem`](LikedFeedResponseCandidatesItem.md)[]

#### Defined in

[src/responses/liked.feed.response.ts:46](https://github.com/Nerixyz/instagram-private-api/blob/0e0721c/src/responses/liked.feed.response.ts#L46)
