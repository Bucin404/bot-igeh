[instagram-private-api](../../README.md) / [index](../../modules/index.md) / LocationRepositoryStoryResponseImage_versions2

# Interface: LocationRepositoryStoryResponseImage\_versions2

[index](../../modules/index.md).LocationRepositoryStoryResponseImage_versions2

## Table of contents

### Properties

- [candidates](LocationRepositoryStoryResponseImage_versions2.md#candidates)

## Properties

### candidates

• **candidates**: [`LocationRepositoryStoryResponseCandidatesItem`](LocationRepositoryStoryResponseCandidatesItem.md)[]

#### Defined in

[src/responses/location.repository.story.response.ts:97](https://github.com/Nerixyz/instagram-private-api/blob/0e0721c/src/responses/location.repository.story.response.ts#L97)
