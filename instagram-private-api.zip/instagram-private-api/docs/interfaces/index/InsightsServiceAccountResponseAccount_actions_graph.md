[instagram-private-api](../../README.md) / [index](../../modules/index.md) / InsightsServiceAccountResponseAccount_actions_graph

# Interface: InsightsServiceAccountResponseAccount\_actions\_graph

[index](../../modules/index.md).InsightsServiceAccountResponseAccount_actions_graph

## Table of contents

### Properties

- [total\_count\_graph](InsightsServiceAccountResponseAccount_actions_graph.md#total_count_graph)

## Properties

### total\_count\_graph

• **total\_count\_graph**: [`InsightsServiceAccountResponseTotal_count_graph`](InsightsServiceAccountResponseTotal_count_graph.md)

#### Defined in

[src/responses/insights.service.account.response.ts:57](https://github.com/Nerixyz/instagram-private-api/blob/0e0721c/src/responses/insights.service.account.response.ts#L57)
