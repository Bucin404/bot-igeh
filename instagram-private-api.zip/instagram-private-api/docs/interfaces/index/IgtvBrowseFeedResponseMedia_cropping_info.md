[instagram-private-api](../../README.md) / [index](../../modules/index.md) / IgtvBrowseFeedResponseMedia_cropping_info

# Interface: IgtvBrowseFeedResponseMedia\_cropping\_info

[index](../../modules/index.md).IgtvBrowseFeedResponseMedia_cropping_info
