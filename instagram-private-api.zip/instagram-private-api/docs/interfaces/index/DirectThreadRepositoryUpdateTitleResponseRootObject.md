[instagram-private-api](../../README.md) / [index](../../modules/index.md) / DirectThreadRepositoryUpdateTitleResponseRootObject

# Interface: DirectThreadRepositoryUpdateTitleResponseRootObject

[index](../../modules/index.md).DirectThreadRepositoryUpdateTitleResponseRootObject

## Table of contents

### Properties

- [status](DirectThreadRepositoryUpdateTitleResponseRootObject.md#status)
- [thread](DirectThreadRepositoryUpdateTitleResponseRootObject.md#thread)

## Properties

### status

• **status**: `string`

#### Defined in

[src/responses/direct-thread.repository.update-title.response.ts:3](https://github.com/Nerixyz/instagram-private-api/blob/0e0721c/src/responses/direct-thread.repository.update-title.response.ts#L3)

___

### thread

• **thread**: [`DirectThreadRepositoryUpdateTitleResponseThread`](DirectThreadRepositoryUpdateTitleResponseThread.md)

#### Defined in

[src/responses/direct-thread.repository.update-title.response.ts:2](https://github.com/Nerixyz/instagram-private-api/blob/0e0721c/src/responses/direct-thread.repository.update-title.response.ts#L2)
