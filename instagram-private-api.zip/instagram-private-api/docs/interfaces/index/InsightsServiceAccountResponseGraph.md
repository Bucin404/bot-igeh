[instagram-private-api](../../README.md) / [index](../../modules/index.md) / InsightsServiceAccountResponseGraph

# Interface: InsightsServiceAccountResponseGraph

[index](../../modules/index.md).InsightsServiceAccountResponseGraph

## Table of contents

### Properties

- [nodes](InsightsServiceAccountResponseGraph.md#nodes)

## Properties

### nodes

• **nodes**: [`InsightsServiceAccountResponseNodesItem`](InsightsServiceAccountResponseNodesItem.md)[]

#### Defined in

[src/responses/insights.service.account.response.ts:98](https://github.com/Nerixyz/instagram-private-api/blob/0e0721c/src/responses/insights.service.account.response.ts#L98)
