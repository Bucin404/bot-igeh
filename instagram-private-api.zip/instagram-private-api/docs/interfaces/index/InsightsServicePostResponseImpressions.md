[instagram-private-api](../../README.md) / [index](../../modules/index.md) / InsightsServicePostResponseImpressions

# Interface: InsightsServicePostResponseImpressions

[index](../../modules/index.md).InsightsServicePostResponseImpressions

## Table of contents

### Properties

- [surfaces](InsightsServicePostResponseImpressions.md#surfaces)
- [value](InsightsServicePostResponseImpressions.md#value)

## Properties

### surfaces

• **surfaces**: [`InsightsServicePostResponseSurfaces`](InsightsServicePostResponseSurfaces.md)

#### Defined in

[src/responses/insights.service.post.response.ts:71](https://github.com/Nerixyz/instagram-private-api/blob/0e0721c/src/responses/insights.service.post.response.ts#L71)

___

### value

• **value**: `number`

#### Defined in

[src/responses/insights.service.post.response.ts:70](https://github.com/Nerixyz/instagram-private-api/blob/0e0721c/src/responses/insights.service.post.response.ts#L70)
