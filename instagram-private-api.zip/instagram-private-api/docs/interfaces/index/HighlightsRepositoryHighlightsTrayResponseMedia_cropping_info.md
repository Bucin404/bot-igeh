[instagram-private-api](../../README.md) / [index](../../modules/index.md) / HighlightsRepositoryHighlightsTrayResponseMedia_cropping_info

# Interface: HighlightsRepositoryHighlightsTrayResponseMedia\_cropping\_info

[index](../../modules/index.md).HighlightsRepositoryHighlightsTrayResponseMedia_cropping_info
