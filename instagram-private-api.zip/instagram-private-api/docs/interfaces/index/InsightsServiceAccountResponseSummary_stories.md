[instagram-private-api](../../README.md) / [index](../../modules/index.md) / InsightsServiceAccountResponseSummary_stories

# Interface: InsightsServiceAccountResponseSummary\_stories

[index](../../modules/index.md).InsightsServiceAccountResponseSummary_stories

## Table of contents

### Properties

- [count](InsightsServiceAccountResponseSummary_stories.md#count)
- [edges](InsightsServiceAccountResponseSummary_stories.md#edges)

## Properties

### count

• **count**: `number`

#### Defined in

[src/responses/insights.service.account.response.ts:158](https://github.com/Nerixyz/instagram-private-api/blob/0e0721c/src/responses/insights.service.account.response.ts#L158)

___

### edges

• **edges**: `any`[]

#### Defined in

[src/responses/insights.service.account.response.ts:159](https://github.com/Nerixyz/instagram-private-api/blob/0e0721c/src/responses/insights.service.account.response.ts#L159)
