[instagram-private-api](../../README.md) / [index](../../modules/index.md) / LiveSwitchCommentsResponseRootObject

# Interface: LiveSwitchCommentsResponseRootObject

[index](../../modules/index.md).LiveSwitchCommentsResponseRootObject

## Table of contents

### Properties

- [comment\_muted](LiveSwitchCommentsResponseRootObject.md#comment_muted)
- [status](LiveSwitchCommentsResponseRootObject.md#status)

## Properties

### comment\_muted

• **comment\_muted**: `number`

#### Defined in

[src/responses/live.switch-comments.response.ts:2](https://github.com/Nerixyz/instagram-private-api/blob/0e0721c/src/responses/live.switch-comments.response.ts#L2)

___

### status

• **status**: `string`

#### Defined in

[src/responses/live.switch-comments.response.ts:3](https://github.com/Nerixyz/instagram-private-api/blob/0e0721c/src/responses/live.switch-comments.response.ts#L3)
