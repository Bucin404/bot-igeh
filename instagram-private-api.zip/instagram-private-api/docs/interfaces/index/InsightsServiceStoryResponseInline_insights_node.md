[instagram-private-api](../../README.md) / [index](../../modules/index.md) / InsightsServiceStoryResponseInline_insights_node

# Interface: InsightsServiceStoryResponseInline\_insights\_node

[index](../../modules/index.md).InsightsServiceStoryResponseInline_insights_node

## Table of contents

### Properties

- [metrics](InsightsServiceStoryResponseInline_insights_node.md#metrics)
- [state](InsightsServiceStoryResponseInline_insights_node.md#state)

## Properties

### metrics

• **metrics**: ``null``

#### Defined in

[src/responses/insights.service.story.response.ts:20](https://github.com/Nerixyz/instagram-private-api/blob/0e0721c/src/responses/insights.service.story.response.ts#L20)

___

### state

• **state**: `string`

#### Defined in

[src/responses/insights.service.story.response.ts:19](https://github.com/Nerixyz/instagram-private-api/blob/0e0721c/src/responses/insights.service.story.response.ts#L19)
