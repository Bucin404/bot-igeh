[instagram-private-api](../../README.md) / [index](../../modules/index.md) / LocationFeedResponseLayout_content

# Interface: LocationFeedResponseLayout\_content

[index](../../modules/index.md).LocationFeedResponseLayout_content

## Table of contents

### Properties

- [medias](LocationFeedResponseLayout_content.md#medias)

## Properties

### medias

• **medias**: [`LocationFeedResponseMediasItem`](LocationFeedResponseMediasItem.md)[]

#### Defined in

[src/responses/location.feed.response.ts:16](https://github.com/Nerixyz/instagram-private-api/blob/0e0721c/src/responses/location.feed.response.ts#L16)
