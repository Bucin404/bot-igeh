[instagram-private-api](../../README.md) / [index](../../modules/index.md) / HighlightsRepositoryCreateReelResponseVideoVersionsItem

# Interface: HighlightsRepositoryCreateReelResponseVideoVersionsItem

[index](../../modules/index.md).HighlightsRepositoryCreateReelResponseVideoVersionsItem

## Table of contents

### Properties

- [height](HighlightsRepositoryCreateReelResponseVideoVersionsItem.md#height)
- [id](HighlightsRepositoryCreateReelResponseVideoVersionsItem.md#id)
- [type](HighlightsRepositoryCreateReelResponseVideoVersionsItem.md#type)
- [url](HighlightsRepositoryCreateReelResponseVideoVersionsItem.md#url)
- [width](HighlightsRepositoryCreateReelResponseVideoVersionsItem.md#width)

## Properties

### height

• **height**: `number`

#### Defined in

[src/responses/highlights.repository.create-reel.response.ts:115](https://github.com/Nerixyz/instagram-private-api/blob/0e0721c/src/responses/highlights.repository.create-reel.response.ts#L115)

___

### id

• **id**: `string`

#### Defined in

[src/responses/highlights.repository.create-reel.response.ts:117](https://github.com/Nerixyz/instagram-private-api/blob/0e0721c/src/responses/highlights.repository.create-reel.response.ts#L117)

___

### type

• **type**: `number`

#### Defined in

[src/responses/highlights.repository.create-reel.response.ts:113](https://github.com/Nerixyz/instagram-private-api/blob/0e0721c/src/responses/highlights.repository.create-reel.response.ts#L113)

___

### url

• **url**: `string`

#### Defined in

[src/responses/highlights.repository.create-reel.response.ts:116](https://github.com/Nerixyz/instagram-private-api/blob/0e0721c/src/responses/highlights.repository.create-reel.response.ts#L116)

___

### width

• **width**: `number`

#### Defined in

[src/responses/highlights.repository.create-reel.response.ts:114](https://github.com/Nerixyz/instagram-private-api/blob/0e0721c/src/responses/highlights.repository.create-reel.response.ts#L114)
