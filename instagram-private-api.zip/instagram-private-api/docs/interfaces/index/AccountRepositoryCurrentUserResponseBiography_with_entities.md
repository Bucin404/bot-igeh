[instagram-private-api](../../README.md) / [index](../../modules/index.md) / AccountRepositoryCurrentUserResponseBiography_with_entities

# Interface: AccountRepositoryCurrentUserResponseBiography\_with\_entities

[index](../../modules/index.md).AccountRepositoryCurrentUserResponseBiography_with_entities

## Table of contents

### Properties

- [entities](AccountRepositoryCurrentUserResponseBiography_with_entities.md#entities)
- [raw\_text](AccountRepositoryCurrentUserResponseBiography_with_entities.md#raw_text)

## Properties

### entities

• **entities**: `any`[]

#### Defined in

[src/responses/account.repository.current-user.response.ts:33](https://github.com/Nerixyz/instagram-private-api/blob/0e0721c/src/responses/account.repository.current-user.response.ts#L33)

___

### raw\_text

• **raw\_text**: `string`

#### Defined in

[src/responses/account.repository.current-user.response.ts:32](https://github.com/Nerixyz/instagram-private-api/blob/0e0721c/src/responses/account.repository.current-user.response.ts#L32)
