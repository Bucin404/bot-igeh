[instagram-private-api](../../README.md) / [index](../../modules/index.md) / InsightsServicePostResponseProfile_actions

# Interface: InsightsServicePostResponseProfile\_actions

[index](../../modules/index.md).InsightsServicePostResponseProfile_actions

## Table of contents

### Properties

- [actions](InsightsServicePostResponseProfile_actions.md#actions)

## Properties

### actions

• **actions**: [`InsightsServicePostResponseActions`](InsightsServicePostResponseActions.md)

#### Defined in

[src/responses/insights.service.post.response.ts:63](https://github.com/Nerixyz/instagram-private-api/blob/0e0721c/src/responses/insights.service.post.response.ts#L63)
