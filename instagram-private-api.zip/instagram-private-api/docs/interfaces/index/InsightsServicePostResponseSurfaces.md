[instagram-private-api](../../README.md) / [index](../../modules/index.md) / InsightsServicePostResponseSurfaces

# Interface: InsightsServicePostResponseSurfaces

[index](../../modules/index.md).InsightsServicePostResponseSurfaces

## Table of contents

### Properties

- [nodes](InsightsServicePostResponseSurfaces.md#nodes)

## Properties

### nodes

• **nodes**: [`InsightsServicePostResponseNodesItem`](InsightsServicePostResponseNodesItem.md)[]

#### Defined in

[src/responses/insights.service.post.response.ts:74](https://github.com/Nerixyz/instagram-private-api/blob/0e0721c/src/responses/insights.service.post.response.ts#L74)
