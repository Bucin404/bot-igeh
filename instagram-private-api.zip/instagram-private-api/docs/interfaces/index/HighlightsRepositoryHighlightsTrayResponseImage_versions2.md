[instagram-private-api](../../README.md) / [index](../../modules/index.md) / HighlightsRepositoryHighlightsTrayResponseImage_versions2

# Interface: HighlightsRepositoryHighlightsTrayResponseImage\_versions2

[index](../../modules/index.md).HighlightsRepositoryHighlightsTrayResponseImage_versions2

## Table of contents

### Properties

- [candidates](HighlightsRepositoryHighlightsTrayResponseImage_versions2.md#candidates)

## Properties

### candidates

• **candidates**: [`HighlightsRepositoryHighlightsTrayResponseCandidatesItem`](HighlightsRepositoryHighlightsTrayResponseCandidatesItem.md)[]

#### Defined in

[src/responses/highlights.repository.highlights-tray.response.ts:102](https://github.com/Nerixyz/instagram-private-api/blob/0e0721c/src/responses/highlights.repository.highlights-tray.response.ts#L102)
