[instagram-private-api](../../README.md) / [index](../../modules/index.md) / FbsearchRepositoryTopsearchFlatResponseHeader_media

# Interface: FbsearchRepositoryTopsearchFlatResponseHeader\_media

[index](../../modules/index.md).FbsearchRepositoryTopsearchFlatResponseHeader_media
