[instagram-private-api](../../README.md) / [index](../../modules/index.md) / HighlightsRepositoryEditReelResponseFb_user_tags

# Interface: HighlightsRepositoryEditReelResponseFb\_user\_tags

[index](../../modules/index.md).HighlightsRepositoryEditReelResponseFb_user_tags

## Table of contents

### Properties

- [in](HighlightsRepositoryEditReelResponseFb_user_tags.md#in)

## Properties

### in

• **in**: `any`[]

#### Defined in

[src/responses/highlights.repository.edit-reel.response.ts:117](https://github.com/Nerixyz/instagram-private-api/blob/0e0721c/src/responses/highlights.repository.edit-reel.response.ts#L117)
