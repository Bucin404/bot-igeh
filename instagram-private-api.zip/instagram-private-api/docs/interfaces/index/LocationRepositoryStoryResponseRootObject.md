[instagram-private-api](../../README.md) / [index](../../modules/index.md) / LocationRepositoryStoryResponseRootObject

# Interface: LocationRepositoryStoryResponseRootObject

[index](../../modules/index.md).LocationRepositoryStoryResponseRootObject

## Table of contents

### Properties

- [status](LocationRepositoryStoryResponseRootObject.md#status)
- [story](LocationRepositoryStoryResponseRootObject.md#story)

## Properties

### status

• **status**: `string`

#### Defined in

[src/responses/location.repository.story.response.ts:3](https://github.com/Nerixyz/instagram-private-api/blob/0e0721c/src/responses/location.repository.story.response.ts#L3)

___

### story

• **story**: [`LocationRepositoryStoryResponseStory`](LocationRepositoryStoryResponseStory.md)

#### Defined in

[src/responses/location.repository.story.response.ts:2](https://github.com/Nerixyz/instagram-private-api/blob/0e0721c/src/responses/location.repository.story.response.ts#L2)
