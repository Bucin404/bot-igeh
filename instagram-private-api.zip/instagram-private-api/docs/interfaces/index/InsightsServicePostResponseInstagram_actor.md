[instagram-private-api](../../README.md) / [index](../../modules/index.md) / InsightsServicePostResponseInstagram_actor

# Interface: InsightsServicePostResponseInstagram\_actor

[index](../../modules/index.md).InsightsServicePostResponseInstagram_actor

## Table of contents

### Properties

- [id](InsightsServicePostResponseInstagram_actor.md#id)
- [instagram\_actor\_id](InsightsServicePostResponseInstagram_actor.md#instagram_actor_id)

## Properties

### id

• **id**: `string`

#### Defined in

[src/responses/insights.service.post.response.ts:28](https://github.com/Nerixyz/instagram-private-api/blob/0e0721c/src/responses/insights.service.post.response.ts#L28)

___

### instagram\_actor\_id

• **instagram\_actor\_id**: `string`

#### Defined in

[src/responses/insights.service.post.response.ts:27](https://github.com/Nerixyz/instagram-private-api/blob/0e0721c/src/responses/insights.service.post.response.ts#L27)
