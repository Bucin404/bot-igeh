[instagram-private-api](../../README.md) / [index](../../modules/index.md) / HighlightsRepositoryEditReelResponseTalliesItem

# Interface: HighlightsRepositoryEditReelResponseTalliesItem

[index](../../modules/index.md).HighlightsRepositoryEditReelResponseTalliesItem

## Table of contents

### Properties

- [count](HighlightsRepositoryEditReelResponseTalliesItem.md#count)
- [text](HighlightsRepositoryEditReelResponseTalliesItem.md#text)

## Properties

### count

• **count**: `number`

#### Defined in

[src/responses/highlights.repository.edit-reel.response.ts:150](https://github.com/Nerixyz/instagram-private-api/blob/0e0721c/src/responses/highlights.repository.edit-reel.response.ts#L150)

___

### text

• **text**: `string`

#### Defined in

[src/responses/highlights.repository.edit-reel.response.ts:149](https://github.com/Nerixyz/instagram-private-api/blob/0e0721c/src/responses/highlights.repository.edit-reel.response.ts#L149)
