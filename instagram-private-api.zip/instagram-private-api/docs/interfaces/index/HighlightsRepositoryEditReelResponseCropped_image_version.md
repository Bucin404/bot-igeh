[instagram-private-api](../../README.md) / [index](../../modules/index.md) / HighlightsRepositoryEditReelResponseCropped_image_version

# Interface: HighlightsRepositoryEditReelResponseCropped\_image\_version

[index](../../modules/index.md).HighlightsRepositoryEditReelResponseCropped_image_version

## Table of contents

### Properties

- [estimated\_scans\_sizes](HighlightsRepositoryEditReelResponseCropped_image_version.md#estimated_scans_sizes)
- [height](HighlightsRepositoryEditReelResponseCropped_image_version.md#height)
- [url](HighlightsRepositoryEditReelResponseCropped_image_version.md#url)
- [width](HighlightsRepositoryEditReelResponseCropped_image_version.md#width)

## Properties

### estimated\_scans\_sizes

• **estimated\_scans\_sizes**: `number`[]

#### Defined in

[src/responses/highlights.repository.edit-reel.response.ts:34](https://github.com/Nerixyz/instagram-private-api/blob/0e0721c/src/responses/highlights.repository.edit-reel.response.ts#L34)

___

### height

• **height**: `number`

#### Defined in

[src/responses/highlights.repository.edit-reel.response.ts:32](https://github.com/Nerixyz/instagram-private-api/blob/0e0721c/src/responses/highlights.repository.edit-reel.response.ts#L32)

___

### url

• **url**: `string`

#### Defined in

[src/responses/highlights.repository.edit-reel.response.ts:33](https://github.com/Nerixyz/instagram-private-api/blob/0e0721c/src/responses/highlights.repository.edit-reel.response.ts#L33)

___

### width

• **width**: `number`

#### Defined in

[src/responses/highlights.repository.edit-reel.response.ts:31](https://github.com/Nerixyz/instagram-private-api/blob/0e0721c/src/responses/highlights.repository.edit-reel.response.ts#L31)
