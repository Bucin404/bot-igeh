[instagram-private-api](../../README.md) / [index](../../modules/index.md) / InsightsServiceAccountResponseOrganic

# Interface: InsightsServiceAccountResponseOrganic

[index](../../modules/index.md).InsightsServiceAccountResponseOrganic

## Table of contents

### Properties

- [status](InsightsServiceAccountResponseOrganic.md#status)
- [value](InsightsServiceAccountResponseOrganic.md#value)

## Properties

### status

• **status**: `string`

#### Defined in

[src/responses/insights.service.account.response.ts:87](https://github.com/Nerixyz/instagram-private-api/blob/0e0721c/src/responses/insights.service.account.response.ts#L87)

___

### value

• **value**: `number`

#### Defined in

[src/responses/insights.service.account.response.ts:86](https://github.com/Nerixyz/instagram-private-api/blob/0e0721c/src/responses/insights.service.account.response.ts#L86)
