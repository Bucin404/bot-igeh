[instagram-private-api](../../README.md) / [index](../../modules/index.md) / DirectThreadRepositoryAddUserResponseBoldItem

# Interface: DirectThreadRepositoryAddUserResponseBoldItem

[index](../../modules/index.md).DirectThreadRepositoryAddUserResponseBoldItem

## Table of contents

### Properties

- [end](DirectThreadRepositoryAddUserResponseBoldItem.md#end)
- [start](DirectThreadRepositoryAddUserResponseBoldItem.md#start)

## Properties

### end

• **end**: `number`

#### Defined in

[src/responses/direct-thread.repository.add-user.response.ts:95](https://github.com/Nerixyz/instagram-private-api/blob/0e0721c/src/responses/direct-thread.repository.add-user.response.ts#L95)

___

### start

• **start**: `number`

#### Defined in

[src/responses/direct-thread.repository.add-user.response.ts:94](https://github.com/Nerixyz/instagram-private-api/blob/0e0721c/src/responses/direct-thread.repository.add-user.response.ts#L94)
