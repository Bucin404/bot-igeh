[instagram-private-api](../../README.md) / [index](../../modules/index.md) / ListReelMediaViewerFeedResponseFb_user_tags

# Interface: ListReelMediaViewerFeedResponseFb\_user\_tags

[index](../../modules/index.md).ListReelMediaViewerFeedResponseFb_user_tags

## Table of contents

### Properties

- [in](ListReelMediaViewerFeedResponseFb_user_tags.md#in)

## Properties

### in

• **in**: `any`[]

#### Defined in

[src/responses/list-reel-media-viewer.feed.response.ts:131](https://github.com/Nerixyz/instagram-private-api/blob/0e0721c/src/responses/list-reel-media-viewer.feed.response.ts#L131)
