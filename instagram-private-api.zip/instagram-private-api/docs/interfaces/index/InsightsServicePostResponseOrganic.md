[instagram-private-api](../../README.md) / [index](../../modules/index.md) / InsightsServicePostResponseOrganic

# Interface: InsightsServicePostResponseOrganic

[index](../../modules/index.md).InsightsServicePostResponseOrganic

## Table of contents

### Properties

- [status](InsightsServicePostResponseOrganic.md#status)
- [value](InsightsServicePostResponseOrganic.md#value)

## Properties

### status

• **status**: `string`

#### Defined in

[src/responses/insights.service.post.response.ts:89](https://github.com/Nerixyz/instagram-private-api/blob/0e0721c/src/responses/insights.service.post.response.ts#L89)

___

### value

• **value**: `number`

#### Defined in

[src/responses/insights.service.post.response.ts:88](https://github.com/Nerixyz/instagram-private-api/blob/0e0721c/src/responses/insights.service.post.response.ts#L88)
