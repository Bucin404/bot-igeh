[instagram-private-api](../../README.md) / [index](../../modules/index.md) / InsightsServicePostResponseHashtags

# Interface: InsightsServicePostResponseHashtags

[index](../../modules/index.md).InsightsServicePostResponseHashtags

## Table of contents

### Properties

- [count](InsightsServicePostResponseHashtags.md#count)
- [nodes](InsightsServicePostResponseHashtags.md#nodes)

## Properties

### count

• **count**: `number`

#### Defined in

[src/responses/insights.service.post.response.ts:92](https://github.com/Nerixyz/instagram-private-api/blob/0e0721c/src/responses/insights.service.post.response.ts#L92)

___

### nodes

• **nodes**: `any`[]

#### Defined in

[src/responses/insights.service.post.response.ts:93](https://github.com/Nerixyz/instagram-private-api/blob/0e0721c/src/responses/insights.service.post.response.ts#L93)
