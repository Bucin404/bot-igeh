[instagram-private-api](../../README.md) / [index](../../modules/index.md) / FriendshipRepositorySetBestiesResponseRootObject

# Interface: FriendshipRepositorySetBestiesResponseRootObject

[index](../../modules/index.md).FriendshipRepositorySetBestiesResponseRootObject

## Table of contents

### Properties

- [friendship\_statuses](FriendshipRepositorySetBestiesResponseRootObject.md#friendship_statuses)
- [status](FriendshipRepositorySetBestiesResponseRootObject.md#status)

## Properties

### friendship\_statuses

• **friendship\_statuses**: `Record`<`string`, [`FriendshipRepositorySetBestiesResponseRootObject_status`](FriendshipRepositorySetBestiesResponseRootObject_status.md)\>

#### Defined in

[src/responses/friendship.repository.besties.response.ts:2](https://github.com/Nerixyz/instagram-private-api/blob/0e0721c/src/responses/friendship.repository.besties.response.ts#L2)

___

### status

• **status**: `string`

#### Defined in

[src/responses/friendship.repository.besties.response.ts:3](https://github.com/Nerixyz/instagram-private-api/blob/0e0721c/src/responses/friendship.repository.besties.response.ts#L3)
