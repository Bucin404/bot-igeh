[instagram-private-api](../../README.md) / [index](../../modules/index.md) / InsightsServiceAccountResponseAccount_hashtags

# Interface: InsightsServiceAccountResponseAccount\_hashtags

[index](../../modules/index.md).InsightsServiceAccountResponseAccount_hashtags

## Table of contents

### Properties

- [count](InsightsServiceAccountResponseAccount_hashtags.md#count)
- [nodes](InsightsServiceAccountResponseAccount_hashtags.md#nodes)

## Properties

### count

• **count**: `number`

#### Defined in

[src/responses/insights.service.account.response.ts:94](https://github.com/Nerixyz/instagram-private-api/blob/0e0721c/src/responses/insights.service.account.response.ts#L94)

___

### nodes

• **nodes**: `any`[]

#### Defined in

[src/responses/insights.service.account.response.ts:95](https://github.com/Nerixyz/instagram-private-api/blob/0e0721c/src/responses/insights.service.account.response.ts#L95)
