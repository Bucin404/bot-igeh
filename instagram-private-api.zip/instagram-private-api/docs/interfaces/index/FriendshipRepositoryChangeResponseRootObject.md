[instagram-private-api](../../README.md) / [index](../../modules/index.md) / FriendshipRepositoryChangeResponseRootObject

# Interface: FriendshipRepositoryChangeResponseRootObject

[index](../../modules/index.md).FriendshipRepositoryChangeResponseRootObject

## Table of contents

### Properties

- [friendship\_status](FriendshipRepositoryChangeResponseRootObject.md#friendship_status)
- [status](FriendshipRepositoryChangeResponseRootObject.md#status)

## Properties

### friendship\_status

• **friendship\_status**: [`FriendshipRepositoryChangeResponseFriendship_status`](FriendshipRepositoryChangeResponseFriendship_status.md)

#### Defined in

[src/responses/friendship.repository.change.response.ts:2](https://github.com/Nerixyz/instagram-private-api/blob/0e0721c/src/responses/friendship.repository.change.response.ts#L2)

___

### status

• **status**: `string`

#### Defined in

[src/responses/friendship.repository.change.response.ts:3](https://github.com/Nerixyz/instagram-private-api/blob/0e0721c/src/responses/friendship.repository.change.response.ts#L3)
