[instagram-private-api](../../README.md) / [index](../../modules/index.md) / IgtvBrowseFeedResponseAdditional_candidates

# Interface: IgtvBrowseFeedResponseAdditional\_candidates

[index](../../modules/index.md).IgtvBrowseFeedResponseAdditional_candidates

## Table of contents

### Properties

- [igtv\_first\_frame](IgtvBrowseFeedResponseAdditional_candidates.md#igtv_first_frame)

## Properties

### igtv\_first\_frame

• **igtv\_first\_frame**: [`IgtvBrowseFeedResponseIgtv_first_frame`](IgtvBrowseFeedResponseIgtv_first_frame.md)

#### Defined in

[src/responses/igtv.browse.feed.response.ts:134](https://github.com/Nerixyz/instagram-private-api/blob/0e0721c/src/responses/igtv.browse.feed.response.ts#L134)
