[instagram-private-api](../../README.md) / [index](../../modules/index.md) / InsightsServiceAccountResponsePromotions_unit

# Interface: InsightsServiceAccountResponsePromotions\_unit

[index](../../modules/index.md).InsightsServiceAccountResponsePromotions_unit

## Table of contents

### Properties

- [summary\_promotions](InsightsServiceAccountResponsePromotions_unit.md#summary_promotions)

## Properties

### summary\_promotions

• **summary\_promotions**: [`InsightsServiceAccountResponseSummary_promotions`](InsightsServiceAccountResponseSummary_promotions.md)

#### Defined in

[src/responses/insights.service.account.response.ts:165](https://github.com/Nerixyz/instagram-private-api/blob/0e0721c/src/responses/insights.service.account.response.ts#L165)
