[instagram-private-api](../../README.md) / [index](../../modules/index.md) / LocationFeedResponseUsertags

# Interface: LocationFeedResponseUsertags

[index](../../modules/index.md).LocationFeedResponseUsertags

## Table of contents

### Properties

- [in](LocationFeedResponseUsertags.md#in)

## Properties

### in

• **in**: [`LocationFeedResponseInItem`](LocationFeedResponseInItem.md)[]

#### Defined in

[src/responses/location.feed.response.ts:155](https://github.com/Nerixyz/instagram-private-api/blob/0e0721c/src/responses/location.feed.response.ts#L155)
