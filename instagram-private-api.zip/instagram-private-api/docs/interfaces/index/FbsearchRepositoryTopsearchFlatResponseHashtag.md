[instagram-private-api](../../README.md) / [index](../../modules/index.md) / FbsearchRepositoryTopsearchFlatResponseHashtag

# Interface: FbsearchRepositoryTopsearchFlatResponseHashtag

[index](../../modules/index.md).FbsearchRepositoryTopsearchFlatResponseHashtag

## Table of contents

### Properties

- [id](FbsearchRepositoryTopsearchFlatResponseHashtag.md#id)
- [media\_count](FbsearchRepositoryTopsearchFlatResponseHashtag.md#media_count)
- [name](FbsearchRepositoryTopsearchFlatResponseHashtag.md#name)
- [profile\_pic\_url](FbsearchRepositoryTopsearchFlatResponseHashtag.md#profile_pic_url)
- [search\_result\_subtitle](FbsearchRepositoryTopsearchFlatResponseHashtag.md#search_result_subtitle)

## Properties

### id

• **id**: `string`

#### Defined in

[src/responses/fbsearch.repository.topsearch-flat.response.ts:35](https://github.com/Nerixyz/instagram-private-api/blob/0e0721c/src/responses/fbsearch.repository.topsearch-flat.response.ts#L35)

___

### media\_count

• **media\_count**: `number`

#### Defined in

[src/responses/fbsearch.repository.topsearch-flat.response.ts:36](https://github.com/Nerixyz/instagram-private-api/blob/0e0721c/src/responses/fbsearch.repository.topsearch-flat.response.ts#L36)

___

### name

• **name**: `string`

#### Defined in

[src/responses/fbsearch.repository.topsearch-flat.response.ts:34](https://github.com/Nerixyz/instagram-private-api/blob/0e0721c/src/responses/fbsearch.repository.topsearch-flat.response.ts#L34)

___

### profile\_pic\_url

• **profile\_pic\_url**: `string`

#### Defined in

[src/responses/fbsearch.repository.topsearch-flat.response.ts:37](https://github.com/Nerixyz/instagram-private-api/blob/0e0721c/src/responses/fbsearch.repository.topsearch-flat.response.ts#L37)

___

### search\_result\_subtitle

• **search\_result\_subtitle**: `string`

#### Defined in

[src/responses/fbsearch.repository.topsearch-flat.response.ts:38](https://github.com/Nerixyz/instagram-private-api/blob/0e0721c/src/responses/fbsearch.repository.topsearch-flat.response.ts#L38)
