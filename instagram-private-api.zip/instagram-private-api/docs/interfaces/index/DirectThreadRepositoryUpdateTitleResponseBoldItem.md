[instagram-private-api](../../README.md) / [index](../../modules/index.md) / DirectThreadRepositoryUpdateTitleResponseBoldItem

# Interface: DirectThreadRepositoryUpdateTitleResponseBoldItem

[index](../../modules/index.md).DirectThreadRepositoryUpdateTitleResponseBoldItem

## Table of contents

### Properties

- [end](DirectThreadRepositoryUpdateTitleResponseBoldItem.md#end)
- [start](DirectThreadRepositoryUpdateTitleResponseBoldItem.md#start)

## Properties

### end

• **end**: `number`

#### Defined in

[src/responses/direct-thread.repository.update-title.response.ts:89](https://github.com/Nerixyz/instagram-private-api/blob/0e0721c/src/responses/direct-thread.repository.update-title.response.ts#L89)

___

### start

• **start**: `number`

#### Defined in

[src/responses/direct-thread.repository.update-title.response.ts:88](https://github.com/Nerixyz/instagram-private-api/blob/0e0721c/src/responses/direct-thread.repository.update-title.response.ts#L88)
