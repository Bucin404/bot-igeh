[instagram-private-api](../../README.md) / [index](../../modules/index.md) / LiveStartBroadcastResponseRootObject

# Interface: LiveStartBroadcastResponseRootObject

[index](../../modules/index.md).LiveStartBroadcastResponseRootObject

## Table of contents

### Properties

- [media\_id](LiveStartBroadcastResponseRootObject.md#media_id)
- [status](LiveStartBroadcastResponseRootObject.md#status)

## Properties

### media\_id

• **media\_id**: `string`

#### Defined in

[src/responses/live.start-broadcast.response.ts:2](https://github.com/Nerixyz/instagram-private-api/blob/0e0721c/src/responses/live.start-broadcast.response.ts#L2)

___

### status

• **status**: `string`

#### Defined in

[src/responses/live.start-broadcast.response.ts:3](https://github.com/Nerixyz/instagram-private-api/blob/0e0721c/src/responses/live.start-broadcast.response.ts#L3)
