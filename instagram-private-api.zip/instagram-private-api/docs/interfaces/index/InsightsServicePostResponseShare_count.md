[instagram-private-api](../../README.md) / [index](../../modules/index.md) / InsightsServicePostResponseShare_count

# Interface: InsightsServicePostResponseShare\_count

[index](../../modules/index.md).InsightsServicePostResponseShare_count

## Table of contents

### Properties

- [post](InsightsServicePostResponseShare_count.md#post)
- [tray](InsightsServicePostResponseShare_count.md#tray)

## Properties

### post

• **post**: [`InsightsServicePostResponsePost`](InsightsServicePostResponsePost.md)

#### Defined in

[src/responses/insights.service.post.response.ts:48](https://github.com/Nerixyz/instagram-private-api/blob/0e0721c/src/responses/insights.service.post.response.ts#L48)

___

### tray

• **tray**: [`InsightsServicePostResponseTray`](InsightsServicePostResponseTray.md)

#### Defined in

[src/responses/insights.service.post.response.ts:47](https://github.com/Nerixyz/instagram-private-api/blob/0e0721c/src/responses/insights.service.post.response.ts#L47)
