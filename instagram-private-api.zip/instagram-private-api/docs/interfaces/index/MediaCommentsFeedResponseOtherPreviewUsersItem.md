[instagram-private-api](../../README.md) / [index](../../modules/index.md) / MediaCommentsFeedResponseOtherPreviewUsersItem

# Interface: MediaCommentsFeedResponseOtherPreviewUsersItem

[index](../../modules/index.md).MediaCommentsFeedResponseOtherPreviewUsersItem

## Table of contents

### Properties

- [id](MediaCommentsFeedResponseOtherPreviewUsersItem.md#id)
- [profile\_pic\_url](MediaCommentsFeedResponseOtherPreviewUsersItem.md#profile_pic_url)

## Properties

### id

• **id**: `number`

#### Defined in

[src/responses/media-comments.feed.response.ts:74](https://github.com/Nerixyz/instagram-private-api/blob/0e0721c/src/responses/media-comments.feed.response.ts#L74)

___

### profile\_pic\_url

• **profile\_pic\_url**: `string`

#### Defined in

[src/responses/media-comments.feed.response.ts:75](https://github.com/Nerixyz/instagram-private-api/blob/0e0721c/src/responses/media-comments.feed.response.ts#L75)
