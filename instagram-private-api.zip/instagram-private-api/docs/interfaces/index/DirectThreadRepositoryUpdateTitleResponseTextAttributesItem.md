[instagram-private-api](../../README.md) / [index](../../modules/index.md) / DirectThreadRepositoryUpdateTitleResponseTextAttributesItem

# Interface: DirectThreadRepositoryUpdateTitleResponseTextAttributesItem

[index](../../modules/index.md).DirectThreadRepositoryUpdateTitleResponseTextAttributesItem

## Table of contents

### Properties

- [bold](DirectThreadRepositoryUpdateTitleResponseTextAttributesItem.md#bold)
- [color](DirectThreadRepositoryUpdateTitleResponseTextAttributesItem.md#color)
- [end](DirectThreadRepositoryUpdateTitleResponseTextAttributesItem.md#end)
- [intent](DirectThreadRepositoryUpdateTitleResponseTextAttributesItem.md#intent)
- [start](DirectThreadRepositoryUpdateTitleResponseTextAttributesItem.md#start)

## Properties

### bold

• **bold**: `number`

#### Defined in

[src/responses/direct-thread.repository.update-title.response.ts:95](https://github.com/Nerixyz/instagram-private-api/blob/0e0721c/src/responses/direct-thread.repository.update-title.response.ts#L95)

___

### color

• **color**: `string`

#### Defined in

[src/responses/direct-thread.repository.update-title.response.ts:96](https://github.com/Nerixyz/instagram-private-api/blob/0e0721c/src/responses/direct-thread.repository.update-title.response.ts#L96)

___

### end

• **end**: `number`

#### Defined in

[src/responses/direct-thread.repository.update-title.response.ts:94](https://github.com/Nerixyz/instagram-private-api/blob/0e0721c/src/responses/direct-thread.repository.update-title.response.ts#L94)

___

### intent

• **intent**: `string`

#### Defined in

[src/responses/direct-thread.repository.update-title.response.ts:97](https://github.com/Nerixyz/instagram-private-api/blob/0e0721c/src/responses/direct-thread.repository.update-title.response.ts#L97)

___

### start

• **start**: `number`

#### Defined in

[src/responses/direct-thread.repository.update-title.response.ts:93](https://github.com/Nerixyz/instagram-private-api/blob/0e0721c/src/responses/direct-thread.repository.update-title.response.ts#L93)
