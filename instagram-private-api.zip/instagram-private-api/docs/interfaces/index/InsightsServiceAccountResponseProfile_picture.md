[instagram-private-api](../../README.md) / [index](../../modules/index.md) / InsightsServiceAccountResponseProfile_picture

# Interface: InsightsServiceAccountResponseProfile\_picture

[index](../../modules/index.md).InsightsServiceAccountResponseProfile_picture

## Table of contents

### Properties

- [uri](InsightsServiceAccountResponseProfile_picture.md#uri)

## Properties

### uri

• **uri**: `string`

#### Defined in

[src/responses/insights.service.account.response.ts:171](https://github.com/Nerixyz/instagram-private-api/blob/0e0721c/src/responses/insights.service.account.response.ts#L171)
