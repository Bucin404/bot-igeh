[instagram-private-api](../../README.md) / [index](../../modules/index.md) / InsightsServiceStoryResponseData

# Interface: InsightsServiceStoryResponseData

[index](../../modules/index.md).InsightsServiceStoryResponseData

## Table of contents

### Properties

- [media](InsightsServiceStoryResponseData.md#media)

## Properties

### media

• **media**: [`InsightsServiceStoryResponseMedia`](InsightsServiceStoryResponseMedia.md)

#### Defined in

[src/responses/insights.service.story.response.ts:5](https://github.com/Nerixyz/instagram-private-api/blob/0e0721c/src/responses/insights.service.story.response.ts#L5)
