[instagram-private-api](../../README.md) / [index](../../modules/index.md) / IgtvBrowseFeedResponseExplore

# Interface: IgtvBrowseFeedResponseExplore

[index](../../modules/index.md).IgtvBrowseFeedResponseExplore

## Table of contents

### Properties

- [explanation](IgtvBrowseFeedResponseExplore.md#explanation)

## Properties

### explanation

• **explanation**: `string`

#### Defined in

[src/responses/igtv.browse.feed.response.ts:191](https://github.com/Nerixyz/instagram-private-api/blob/0e0721c/src/responses/igtv.browse.feed.response.ts#L191)
