[instagram-private-api](../../README.md) / [index](../../modules/index.md) / IgtvBrowseFeedResponseSeen_state

# Interface: IgtvBrowseFeedResponseSeen\_state

[index](../../modules/index.md).IgtvBrowseFeedResponseSeen_state
