[instagram-private-api](../../README.md) / [index](../../modules/index.md) / AccountRepositoryCurrentUserResponseHdProfilePicVersionsItem

# Interface: AccountRepositoryCurrentUserResponseHdProfilePicVersionsItem

[index](../../modules/index.md).AccountRepositoryCurrentUserResponseHdProfilePicVersionsItem

## Table of contents

### Properties

- [height](AccountRepositoryCurrentUserResponseHdProfilePicVersionsItem.md#height)
- [url](AccountRepositoryCurrentUserResponseHdProfilePicVersionsItem.md#url)
- [width](AccountRepositoryCurrentUserResponseHdProfilePicVersionsItem.md#width)

## Properties

### height

• **height**: `number`

#### Defined in

[src/responses/account.repository.current-user.response.ts:37](https://github.com/Nerixyz/instagram-private-api/blob/0e0721c/src/responses/account.repository.current-user.response.ts#L37)

___

### url

• **url**: `string`

#### Defined in

[src/responses/account.repository.current-user.response.ts:38](https://github.com/Nerixyz/instagram-private-api/blob/0e0721c/src/responses/account.repository.current-user.response.ts#L38)

___

### width

• **width**: `number`

#### Defined in

[src/responses/account.repository.current-user.response.ts:36](https://github.com/Nerixyz/instagram-private-api/blob/0e0721c/src/responses/account.repository.current-user.response.ts#L36)
