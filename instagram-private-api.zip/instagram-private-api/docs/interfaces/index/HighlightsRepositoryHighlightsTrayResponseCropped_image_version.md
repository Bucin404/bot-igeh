[instagram-private-api](../../README.md) / [index](../../modules/index.md) / HighlightsRepositoryHighlightsTrayResponseCropped_image_version

# Interface: HighlightsRepositoryHighlightsTrayResponseCropped\_image\_version

[index](../../modules/index.md).HighlightsRepositoryHighlightsTrayResponseCropped_image_version

## Table of contents

### Properties

- [estimated\_scans\_sizes](HighlightsRepositoryHighlightsTrayResponseCropped_image_version.md#estimated_scans_sizes)
- [height](HighlightsRepositoryHighlightsTrayResponseCropped_image_version.md#height)
- [url](HighlightsRepositoryHighlightsTrayResponseCropped_image_version.md#url)
- [width](HighlightsRepositoryHighlightsTrayResponseCropped_image_version.md#width)

## Properties

### estimated\_scans\_sizes

• **estimated\_scans\_sizes**: `number`[]

#### Defined in

[src/responses/highlights.repository.highlights-tray.response.ts:32](https://github.com/Nerixyz/instagram-private-api/blob/0e0721c/src/responses/highlights.repository.highlights-tray.response.ts#L32)

___

### height

• **height**: `number`

#### Defined in

[src/responses/highlights.repository.highlights-tray.response.ts:30](https://github.com/Nerixyz/instagram-private-api/blob/0e0721c/src/responses/highlights.repository.highlights-tray.response.ts#L30)

___

### url

• **url**: `string`

#### Defined in

[src/responses/highlights.repository.highlights-tray.response.ts:31](https://github.com/Nerixyz/instagram-private-api/blob/0e0721c/src/responses/highlights.repository.highlights-tray.response.ts#L31)

___

### width

• **width**: `number`

#### Defined in

[src/responses/highlights.repository.highlights-tray.response.ts:29](https://github.com/Nerixyz/instagram-private-api/blob/0e0721c/src/responses/highlights.repository.highlights-tray.response.ts#L29)
