[instagram-private-api](../../README.md) / [index](../../modules/index.md) / DirectInboxFeedResponseMedia

# Interface: DirectInboxFeedResponseMedia

[index](../../modules/index.md).DirectInboxFeedResponseMedia

## Table of contents

### Properties

- [expiring\_at](DirectInboxFeedResponseMedia.md#expiring_at)
- [user](DirectInboxFeedResponseMedia.md#user)

## Properties

### expiring\_at

• **expiring\_at**: `number`

#### Defined in

[src/responses/direct-inbox.feed.response.ts:136](https://github.com/Nerixyz/instagram-private-api/blob/0e0721c/src/responses/direct-inbox.feed.response.ts#L136)

___

### user

• **user**: [`DirectInboxFeedResponseUser`](DirectInboxFeedResponseUser.md)

#### Defined in

[src/responses/direct-inbox.feed.response.ts:135](https://github.com/Nerixyz/instagram-private-api/blob/0e0721c/src/responses/direct-inbox.feed.response.ts#L135)
