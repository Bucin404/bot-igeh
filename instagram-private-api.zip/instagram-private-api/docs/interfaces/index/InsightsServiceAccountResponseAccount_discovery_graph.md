[instagram-private-api](../../README.md) / [index](../../modules/index.md) / InsightsServiceAccountResponseAccount_discovery_graph

# Interface: InsightsServiceAccountResponseAccount\_discovery\_graph

[index](../../modules/index.md).InsightsServiceAccountResponseAccount_discovery_graph

## Table of contents

### Properties

- [nodes](InsightsServiceAccountResponseAccount_discovery_graph.md#nodes)

## Properties

### nodes

• **nodes**: [`InsightsServiceAccountResponseNodesItem`](InsightsServiceAccountResponseNodesItem.md)[]

#### Defined in

[src/responses/insights.service.account.response.ts:68](https://github.com/Nerixyz/instagram-private-api/blob/0e0721c/src/responses/insights.service.account.response.ts#L68)
