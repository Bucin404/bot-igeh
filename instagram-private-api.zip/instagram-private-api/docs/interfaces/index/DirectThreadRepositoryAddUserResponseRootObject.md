[instagram-private-api](../../README.md) / [index](../../modules/index.md) / DirectThreadRepositoryAddUserResponseRootObject

# Interface: DirectThreadRepositoryAddUserResponseRootObject

[index](../../modules/index.md).DirectThreadRepositoryAddUserResponseRootObject

## Table of contents

### Properties

- [status](DirectThreadRepositoryAddUserResponseRootObject.md#status)
- [thread](DirectThreadRepositoryAddUserResponseRootObject.md#thread)

## Properties

### status

• **status**: `string`

#### Defined in

[src/responses/direct-thread.repository.add-user.response.ts:3](https://github.com/Nerixyz/instagram-private-api/blob/0e0721c/src/responses/direct-thread.repository.add-user.response.ts#L3)

___

### thread

• **thread**: [`DirectThreadRepositoryAddUserResponseThread`](DirectThreadRepositoryAddUserResponseThread.md)

#### Defined in

[src/responses/direct-thread.repository.add-user.response.ts:2](https://github.com/Nerixyz/instagram-private-api/blob/0e0721c/src/responses/direct-thread.repository.add-user.response.ts#L2)
