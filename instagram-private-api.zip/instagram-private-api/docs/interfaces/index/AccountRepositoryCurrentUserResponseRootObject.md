[instagram-private-api](../../README.md) / [index](../../modules/index.md) / AccountRepositoryCurrentUserResponseRootObject

# Interface: AccountRepositoryCurrentUserResponseRootObject

[index](../../modules/index.md).AccountRepositoryCurrentUserResponseRootObject

## Table of contents

### Properties

- [status](AccountRepositoryCurrentUserResponseRootObject.md#status)
- [user](AccountRepositoryCurrentUserResponseRootObject.md#user)

## Properties

### status

• **status**: `string`

#### Defined in

[src/responses/account.repository.current-user.response.ts:3](https://github.com/Nerixyz/instagram-private-api/blob/0e0721c/src/responses/account.repository.current-user.response.ts#L3)

___

### user

• **user**: [`AccountRepositoryCurrentUserResponseUser`](AccountRepositoryCurrentUserResponseUser.md)

#### Defined in

[src/responses/account.repository.current-user.response.ts:2](https://github.com/Nerixyz/instagram-private-api/blob/0e0721c/src/responses/account.repository.current-user.response.ts#L2)
