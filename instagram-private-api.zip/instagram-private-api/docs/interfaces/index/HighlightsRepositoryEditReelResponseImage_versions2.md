[instagram-private-api](../../README.md) / [index](../../modules/index.md) / HighlightsRepositoryEditReelResponseImage_versions2

# Interface: HighlightsRepositoryEditReelResponseImage\_versions2

[index](../../modules/index.md).HighlightsRepositoryEditReelResponseImage_versions2

## Table of contents

### Properties

- [candidates](HighlightsRepositoryEditReelResponseImage_versions2.md#candidates)

## Properties

### candidates

• **candidates**: [`HighlightsRepositoryEditReelResponseCandidatesItem`](HighlightsRepositoryEditReelResponseCandidatesItem.md)[]

#### Defined in

[src/responses/highlights.repository.edit-reel.response.ts:108](https://github.com/Nerixyz/instagram-private-api/blob/0e0721c/src/responses/highlights.repository.edit-reel.response.ts#L108)
