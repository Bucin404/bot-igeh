[instagram-private-api](../../README.md) / [index](../../modules/index.md) / InsightsServicePostResponseReach

# Interface: InsightsServicePostResponseReach

[index](../../modules/index.md).InsightsServicePostResponseReach

## Table of contents

### Properties

- [follow\_status](InsightsServicePostResponseReach.md#follow_status)
- [value](InsightsServicePostResponseReach.md#value)

## Properties

### follow\_status

• **follow\_status**: [`InsightsServicePostResponseFollow_status`](InsightsServicePostResponseFollow_status.md)

#### Defined in

[src/responses/insights.service.post.response.ts:78](https://github.com/Nerixyz/instagram-private-api/blob/0e0721c/src/responses/insights.service.post.response.ts#L78)

___

### value

• **value**: `number`

#### Defined in

[src/responses/insights.service.post.response.ts:77](https://github.com/Nerixyz/instagram-private-api/blob/0e0721c/src/responses/insights.service.post.response.ts#L77)
