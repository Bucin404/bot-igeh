[instagram-private-api](../../README.md) / [index](../../modules/index.md) / HighlightsRepositoryHighlightsTrayResponseVideoVersionsItem

# Interface: HighlightsRepositoryHighlightsTrayResponseVideoVersionsItem

[index](../../modules/index.md).HighlightsRepositoryHighlightsTrayResponseVideoVersionsItem

## Table of contents

### Properties

- [height](HighlightsRepositoryHighlightsTrayResponseVideoVersionsItem.md#height)
- [id](HighlightsRepositoryHighlightsTrayResponseVideoVersionsItem.md#id)
- [type](HighlightsRepositoryHighlightsTrayResponseVideoVersionsItem.md#type)
- [url](HighlightsRepositoryHighlightsTrayResponseVideoVersionsItem.md#url)
- [width](HighlightsRepositoryHighlightsTrayResponseVideoVersionsItem.md#width)

## Properties

### height

• **height**: `number`

#### Defined in

[src/responses/highlights.repository.highlights-tray.response.ts:113](https://github.com/Nerixyz/instagram-private-api/blob/0e0721c/src/responses/highlights.repository.highlights-tray.response.ts#L113)

___

### id

• **id**: `string`

#### Defined in

[src/responses/highlights.repository.highlights-tray.response.ts:115](https://github.com/Nerixyz/instagram-private-api/blob/0e0721c/src/responses/highlights.repository.highlights-tray.response.ts#L115)

___

### type

• **type**: `number`

#### Defined in

[src/responses/highlights.repository.highlights-tray.response.ts:111](https://github.com/Nerixyz/instagram-private-api/blob/0e0721c/src/responses/highlights.repository.highlights-tray.response.ts#L111)

___

### url

• **url**: `string`

#### Defined in

[src/responses/highlights.repository.highlights-tray.response.ts:114](https://github.com/Nerixyz/instagram-private-api/blob/0e0721c/src/responses/highlights.repository.highlights-tray.response.ts#L114)

___

### width

• **width**: `number`

#### Defined in

[src/responses/highlights.repository.highlights-tray.response.ts:112](https://github.com/Nerixyz/instagram-private-api/blob/0e0721c/src/responses/highlights.repository.highlights-tray.response.ts#L112)
