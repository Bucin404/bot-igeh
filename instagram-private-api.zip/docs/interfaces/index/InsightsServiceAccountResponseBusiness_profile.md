[instagram-private-api](../../README.md) / [index](../../modules/index.md) / InsightsServiceAccountResponseBusiness_profile

# Interface: InsightsServiceAccountResponseBusiness\_profile

[index](../../modules/index.md).InsightsServiceAccountResponseBusiness_profile

## Table of contents

### Properties

- [id](InsightsServiceAccountResponseBusiness_profile.md#id)

## Properties

### id

• **id**: `string`

#### Defined in

[src/responses/insights.service.account.response.ts:174](https://github.com/Nerixyz/instagram-private-api/blob/0e0721c/src/responses/insights.service.account.response.ts#L174)
