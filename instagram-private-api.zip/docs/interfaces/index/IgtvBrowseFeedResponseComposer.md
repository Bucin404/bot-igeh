[instagram-private-api](../../README.md) / [index](../../modules/index.md) / IgtvBrowseFeedResponseComposer

# Interface: IgtvBrowseFeedResponseComposer

[index](../../modules/index.md).IgtvBrowseFeedResponseComposer

## Table of contents

### Properties

- [aspect\_ratio\_finished](IgtvBrowseFeedResponseComposer.md#aspect_ratio_finished)
- [nux\_finished](IgtvBrowseFeedResponseComposer.md#nux_finished)

## Properties

### aspect\_ratio\_finished

• **aspect\_ratio\_finished**: `boolean`

#### Defined in

[src/responses/igtv.browse.feed.response.ts:76](https://github.com/Nerixyz/instagram-private-api/blob/0e0721c/src/responses/igtv.browse.feed.response.ts#L76)

___

### nux\_finished

• **nux\_finished**: `boolean`

#### Defined in

[src/responses/igtv.browse.feed.response.ts:75](https://github.com/Nerixyz/instagram-private-api/blob/0e0721c/src/responses/igtv.browse.feed.response.ts#L75)
