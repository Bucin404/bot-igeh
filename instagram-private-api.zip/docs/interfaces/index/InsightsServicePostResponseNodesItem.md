[instagram-private-api](../../README.md) / [index](../../modules/index.md) / InsightsServicePostResponseNodesItem

# Interface: InsightsServicePostResponseNodesItem

[index](../../modules/index.md).InsightsServicePostResponseNodesItem

## Table of contents

### Properties

- [\_\_typename](InsightsServicePostResponseNodesItem.md#__typename)
- [name](InsightsServicePostResponseNodesItem.md#name)
- [value](InsightsServicePostResponseNodesItem.md#value)

## Properties

### \_\_typename

• **\_\_typename**: `string`

#### Defined in

[src/responses/insights.service.post.response.ts:54](https://github.com/Nerixyz/instagram-private-api/blob/0e0721c/src/responses/insights.service.post.response.ts#L54)

___

### name

• `Optional` **name**: `string`

#### Defined in

[src/responses/insights.service.post.response.ts:56](https://github.com/Nerixyz/instagram-private-api/blob/0e0721c/src/responses/insights.service.post.response.ts#L56)

___

### value

• **value**: `number`

#### Defined in

[src/responses/insights.service.post.response.ts:55](https://github.com/Nerixyz/instagram-private-api/blob/0e0721c/src/responses/insights.service.post.response.ts#L55)
