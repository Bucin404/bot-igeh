[instagram-private-api](../../README.md) / [index](../../modules/index.md) / HighlightsRepositoryHighlightsTrayResponseSeen_state

# Interface: HighlightsRepositoryHighlightsTrayResponseSeen\_state

[index](../../modules/index.md).HighlightsRepositoryHighlightsTrayResponseSeen_state
