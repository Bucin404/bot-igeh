[instagram-private-api](../../README.md) / [index](../../modules/index.md) / LikedFeedResponseUsertags

# Interface: LikedFeedResponseUsertags

[index](../../modules/index.md).LikedFeedResponseUsertags

## Table of contents

### Properties

- [in](LikedFeedResponseUsertags.md#in)

## Properties

### in

• **in**: [`LikedFeedResponseInItem`](LikedFeedResponseInItem.md)[]

#### Defined in

[src/responses/liked.feed.response.ts:119](https://github.com/Nerixyz/instagram-private-api/blob/0e0721c/src/responses/liked.feed.response.ts#L119)
