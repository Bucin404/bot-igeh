[instagram-private-api](../../README.md) / [index](../../modules/index.md) / LiveGetQuestionsResponseRootObject

# Interface: LiveGetQuestionsResponseRootObject

[index](../../modules/index.md).LiveGetQuestionsResponseRootObject

## Table of contents

### Properties

- [questions](LiveGetQuestionsResponseRootObject.md#questions)
- [status](LiveGetQuestionsResponseRootObject.md#status)

## Properties

### questions

• **questions**: [`LiveGetQuestionsResponseQuestionsItem`](LiveGetQuestionsResponseQuestionsItem.md)[]

#### Defined in

[src/responses/live.get-questions.response.ts:2](https://github.com/Nerixyz/instagram-private-api/blob/0e0721c/src/responses/live.get-questions.response.ts#L2)

___

### status

• **status**: `string`

#### Defined in

[src/responses/live.get-questions.response.ts:3](https://github.com/Nerixyz/instagram-private-api/blob/0e0721c/src/responses/live.get-questions.response.ts#L3)
