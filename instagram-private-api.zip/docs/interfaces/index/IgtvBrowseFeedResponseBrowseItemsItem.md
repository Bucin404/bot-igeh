[instagram-private-api](../../README.md) / [index](../../modules/index.md) / IgtvBrowseFeedResponseBrowseItemsItem

# Interface: IgtvBrowseFeedResponseBrowseItemsItem

[index](../../modules/index.md).IgtvBrowseFeedResponseBrowseItemsItem

## Table of contents

### Properties

- [item](IgtvBrowseFeedResponseBrowseItemsItem.md#item)
- [type](IgtvBrowseFeedResponseBrowseItemsItem.md#type)

## Properties

### item

• **item**: [`IgtvBrowseFeedResponseItem`](IgtvBrowseFeedResponseItem.md)

#### Defined in

[src/responses/igtv.browse.feed.response.ts:80](https://github.com/Nerixyz/instagram-private-api/blob/0e0721c/src/responses/igtv.browse.feed.response.ts#L80)

___

### type

• **type**: `string`

#### Defined in

[src/responses/igtv.browse.feed.response.ts:79](https://github.com/Nerixyz/instagram-private-api/blob/0e0721c/src/responses/igtv.browse.feed.response.ts#L79)
