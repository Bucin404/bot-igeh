[instagram-private-api](../../README.md) / [index](../../modules/index.md) / DirectThreadRepositoryApproveParticipantRequestResponseLast_seen_at

# Interface: DirectThreadRepositoryApproveParticipantRequestResponseLast\_seen\_at

[index](../../modules/index.md).DirectThreadRepositoryApproveParticipantRequestResponseLast_seen_at
