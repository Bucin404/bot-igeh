[instagram-private-api](../../README.md) / [index](../../modules/index.md) / LivePostLiveThumbnailsResponseRootObject

# Interface: LivePostLiveThumbnailsResponseRootObject

[index](../../modules/index.md).LivePostLiveThumbnailsResponseRootObject

## Table of contents

### Properties

- [status](LivePostLiveThumbnailsResponseRootObject.md#status)
- [thumbnails](LivePostLiveThumbnailsResponseRootObject.md#thumbnails)

## Properties

### status

• **status**: `string`

#### Defined in

[src/responses/live.post-live-thumbnails.response.ts:3](https://github.com/Nerixyz/instagram-private-api/blob/0e0721c/src/responses/live.post-live-thumbnails.response.ts#L3)

___

### thumbnails

• **thumbnails**: `string`[]

#### Defined in

[src/responses/live.post-live-thumbnails.response.ts:2](https://github.com/Nerixyz/instagram-private-api/blob/0e0721c/src/responses/live.post-live-thumbnails.response.ts#L2)
