[instagram-private-api](../../README.md) / [index](../../modules/index.md) / IgtvChannelFeedResponseMedia_cropping_info

# Interface: IgtvChannelFeedResponseMedia\_cropping\_info

[index](../../modules/index.md).IgtvChannelFeedResponseMedia_cropping_info
