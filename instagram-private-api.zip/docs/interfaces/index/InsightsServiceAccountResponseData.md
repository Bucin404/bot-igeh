[instagram-private-api](../../README.md) / [index](../../modules/index.md) / InsightsServiceAccountResponseData

# Interface: InsightsServiceAccountResponseData

[index](../../modules/index.md).InsightsServiceAccountResponseData

## Table of contents

### Properties

- [user](InsightsServiceAccountResponseData.md#user)

## Properties

### user

• **user**: [`InsightsServiceAccountResponseUser`](InsightsServiceAccountResponseUser.md)

#### Defined in

[src/responses/insights.service.account.response.ts:5](https://github.com/Nerixyz/instagram-private-api/blob/0e0721c/src/responses/insights.service.account.response.ts#L5)
