[instagram-private-api](../../README.md) / [index](../../modules/index.md) / InsightsServiceAccountResponseAccount_summary_unit

# Interface: InsightsServiceAccountResponseAccount\_summary\_unit

[index](../../modules/index.md).InsightsServiceAccountResponseAccount_summary_unit

## Table of contents

### Properties

- [posts\_count](InsightsServiceAccountResponseAccount_summary_unit.md#posts_count)

## Properties

### posts\_count

• **posts\_count**: `number`

#### Defined in

[src/responses/insights.service.account.response.ts:162](https://github.com/Nerixyz/instagram-private-api/blob/0e0721c/src/responses/insights.service.account.response.ts#L162)
