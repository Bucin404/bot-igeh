[instagram-private-api](../../README.md) / [index](../../modules/index.md) / HighlightsRepositoryEditReelResponseFull_image_version

# Interface: HighlightsRepositoryEditReelResponseFull\_image\_version

[index](../../modules/index.md).HighlightsRepositoryEditReelResponseFull_image_version

## Table of contents

### Properties

- [estimated\_scans\_sizes](HighlightsRepositoryEditReelResponseFull_image_version.md#estimated_scans_sizes)
- [height](HighlightsRepositoryEditReelResponseFull_image_version.md#height)
- [url](HighlightsRepositoryEditReelResponseFull_image_version.md#url)
- [width](HighlightsRepositoryEditReelResponseFull_image_version.md#width)

## Properties

### estimated\_scans\_sizes

• **estimated\_scans\_sizes**: `number`[]

#### Defined in

[src/responses/highlights.repository.edit-reel.response.ts:40](https://github.com/Nerixyz/instagram-private-api/blob/0e0721c/src/responses/highlights.repository.edit-reel.response.ts#L40)

___

### height

• **height**: `number`

#### Defined in

[src/responses/highlights.repository.edit-reel.response.ts:38](https://github.com/Nerixyz/instagram-private-api/blob/0e0721c/src/responses/highlights.repository.edit-reel.response.ts#L38)

___

### url

• **url**: `string`

#### Defined in

[src/responses/highlights.repository.edit-reel.response.ts:39](https://github.com/Nerixyz/instagram-private-api/blob/0e0721c/src/responses/highlights.repository.edit-reel.response.ts#L39)

___

### width

• **width**: `number`

#### Defined in

[src/responses/highlights.repository.edit-reel.response.ts:37](https://github.com/Nerixyz/instagram-private-api/blob/0e0721c/src/responses/highlights.repository.edit-reel.response.ts#L37)
