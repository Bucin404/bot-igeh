[instagram-private-api](../../README.md) / [index](../../modules/index.md) / DiscoverFeedResponseSuggested_users

# Interface: DiscoverFeedResponseSuggested\_users

[index](../../modules/index.md).DiscoverFeedResponseSuggested_users

## Table of contents

### Properties

- [suggestions](DiscoverFeedResponseSuggested_users.md#suggestions)

## Properties

### suggestions

• **suggestions**: [`DiscoverFeedResponseSuggestionsItem`](DiscoverFeedResponseSuggestionsItem.md)[]

#### Defined in

[src/responses/discover.feed.response.ts:12](https://github.com/Nerixyz/instagram-private-api/blob/0e0721c/src/responses/discover.feed.response.ts#L12)
