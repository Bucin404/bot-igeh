[instagram-private-api](../../README.md) / [index](../../modules/index.md) / InsightsServiceAccountResponseTop_posts

# Interface: InsightsServiceAccountResponseTop\_posts

[index](../../modules/index.md).InsightsServiceAccountResponseTop_posts

## Table of contents

### Properties

- [edges](InsightsServiceAccountResponseTop_posts.md#edges)

## Properties

### edges

• **edges**: `any`[]

#### Defined in

[src/responses/insights.service.account.response.ts:149](https://github.com/Nerixyz/instagram-private-api/blob/0e0721c/src/responses/insights.service.account.response.ts#L149)
