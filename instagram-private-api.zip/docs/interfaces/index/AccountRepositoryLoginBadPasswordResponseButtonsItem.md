[instagram-private-api](../../README.md) / [index](../../modules/index.md) / AccountRepositoryLoginBadPasswordResponseButtonsItem

# Interface: AccountRepositoryLoginBadPasswordResponseButtonsItem

[index](../../modules/index.md).AccountRepositoryLoginBadPasswordResponseButtonsItem

## Table of contents

### Properties

- [action](AccountRepositoryLoginBadPasswordResponseButtonsItem.md#action)
- [title](AccountRepositoryLoginBadPasswordResponseButtonsItem.md#title)

## Properties

### action

• **action**: `string`

#### Defined in

[src/responses/account.repository.login.error.response.ts:32](https://github.com/Nerixyz/instagram-private-api/blob/0e0721c/src/responses/account.repository.login.error.response.ts#L32)

___

### title

• **title**: `string`

#### Defined in

[src/responses/account.repository.login.error.response.ts:31](https://github.com/Nerixyz/instagram-private-api/blob/0e0721c/src/responses/account.repository.login.error.response.ts#L31)
