[instagram-private-api](../../README.md) / [index](../../modules/index.md) / MediaInfoResponseImage_versions2

# Interface: MediaInfoResponseImage\_versions2

[index](../../modules/index.md).MediaInfoResponseImage_versions2

## Table of contents

### Properties

- [candidates](MediaInfoResponseImage_versions2.md#candidates)

## Properties

### candidates

• **candidates**: [`MediaInfoResponseCandidatesItem`](MediaInfoResponseCandidatesItem.md)[]

#### Defined in

[src/responses/media.repository.info.response.ts:41](https://github.com/Nerixyz/instagram-private-api/blob/0e0721c/src/responses/media.repository.info.response.ts#L41)
