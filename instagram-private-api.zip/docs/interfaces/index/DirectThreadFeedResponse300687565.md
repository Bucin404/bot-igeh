[instagram-private-api](../../README.md) / [index](../../modules/index.md) / DirectThreadFeedResponse300687565

# Interface: DirectThreadFeedResponse300687565

[index](../../modules/index.md).DirectThreadFeedResponse300687565

## Table of contents

### Properties

- [item\_id](DirectThreadFeedResponse300687565.md#item_id)
- [timestamp](DirectThreadFeedResponse300687565.md#timestamp)

## Properties

### item\_id

• **item\_id**: `string`

#### Defined in

[src/responses/direct-thread.feed.response.ts:62](https://github.com/Nerixyz/instagram-private-api/blob/0e0721c/src/responses/direct-thread.feed.response.ts#L62)

___

### timestamp

• **timestamp**: `string`

#### Defined in

[src/responses/direct-thread.feed.response.ts:61](https://github.com/Nerixyz/instagram-private-api/blob/0e0721c/src/responses/direct-thread.feed.response.ts#L61)
