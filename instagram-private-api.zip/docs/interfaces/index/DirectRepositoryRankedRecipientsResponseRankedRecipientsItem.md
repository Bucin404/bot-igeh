[instagram-private-api](../../README.md) / [index](../../modules/index.md) / DirectRepositoryRankedRecipientsResponseRankedRecipientsItem

# Interface: DirectRepositoryRankedRecipientsResponseRankedRecipientsItem

[index](../../modules/index.md).DirectRepositoryRankedRecipientsResponseRankedRecipientsItem

## Table of contents

### Properties

- [thread](DirectRepositoryRankedRecipientsResponseRankedRecipientsItem.md#thread)
- [user](DirectRepositoryRankedRecipientsResponseRankedRecipientsItem.md#user)

## Properties

### thread

• `Optional` **thread**: [`DirectRepositoryRankedRecipientsResponseThread`](DirectRepositoryRankedRecipientsResponseThread.md)

#### Defined in

[src/responses/direct.repository.ranked-recipients.response.ts:11](https://github.com/Nerixyz/instagram-private-api/blob/0e0721c/src/responses/direct.repository.ranked-recipients.response.ts#L11)

___

### user

• `Optional` **user**: [`DirectRepositoryRankedRecipientsResponseUser`](DirectRepositoryRankedRecipientsResponseUser.md)

#### Defined in

[src/responses/direct.repository.ranked-recipients.response.ts:10](https://github.com/Nerixyz/instagram-private-api/blob/0e0721c/src/responses/direct.repository.ranked-recipients.response.ts#L10)
