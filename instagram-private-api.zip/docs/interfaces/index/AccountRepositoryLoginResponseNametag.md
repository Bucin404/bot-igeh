[instagram-private-api](../../README.md) / [index](../../modules/index.md) / AccountRepositoryLoginResponseNametag

# Interface: AccountRepositoryLoginResponseNametag

[index](../../modules/index.md).AccountRepositoryLoginResponseNametag

## Table of contents

### Properties

- [emoji](AccountRepositoryLoginResponseNametag.md#emoji)
- [gradient](AccountRepositoryLoginResponseNametag.md#gradient)
- [mode](AccountRepositoryLoginResponseNametag.md#mode)
- [selfie\_sticker](AccountRepositoryLoginResponseNametag.md#selfie_sticker)

## Properties

### emoji

• **emoji**: `string`

#### Defined in

[src/responses/account.repository.login.response.ts:32](https://github.com/Nerixyz/instagram-private-api/blob/0e0721c/src/responses/account.repository.login.response.ts#L32)

___

### gradient

• **gradient**: `string`

#### Defined in

[src/responses/account.repository.login.response.ts:31](https://github.com/Nerixyz/instagram-private-api/blob/0e0721c/src/responses/account.repository.login.response.ts#L31)

___

### mode

• **mode**: `number`

#### Defined in

[src/responses/account.repository.login.response.ts:30](https://github.com/Nerixyz/instagram-private-api/blob/0e0721c/src/responses/account.repository.login.response.ts#L30)

___

### selfie\_sticker

• **selfie\_sticker**: `string`

#### Defined in

[src/responses/account.repository.login.response.ts:33](https://github.com/Nerixyz/instagram-private-api/blob/0e0721c/src/responses/account.repository.login.response.ts#L33)
