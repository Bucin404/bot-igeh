[instagram-private-api](../../README.md) / [index](../../modules/index.md) / IgtvBrowseFeedResponseBiography_with_entities

# Interface: IgtvBrowseFeedResponseBiography\_with\_entities

[index](../../modules/index.md).IgtvBrowseFeedResponseBiography_with_entities

## Table of contents

### Properties

- [entities](IgtvBrowseFeedResponseBiography_with_entities.md#entities)
- [raw\_text](IgtvBrowseFeedResponseBiography_with_entities.md#raw_text)

## Properties

### entities

• **entities**: `any`[]

#### Defined in

[src/responses/igtv.browse.feed.response.ts:61](https://github.com/Nerixyz/instagram-private-api/blob/0e0721c/src/responses/igtv.browse.feed.response.ts#L61)

___

### raw\_text

• **raw\_text**: `string`

#### Defined in

[src/responses/igtv.browse.feed.response.ts:60](https://github.com/Nerixyz/instagram-private-api/blob/0e0721c/src/responses/igtv.browse.feed.response.ts#L60)
