[instagram-private-api](../../README.md) / [index](../../modules/index.md) / InsightsServicePostResponsePost

# Interface: InsightsServicePostResponsePost

[index](../../modules/index.md).InsightsServicePostResponsePost

## Table of contents

### Properties

- [nodes](InsightsServicePostResponsePost.md#nodes)
- [value](InsightsServicePostResponsePost.md#value)

## Properties

### nodes

• **nodes**: [`InsightsServicePostResponseNodesItem`](InsightsServicePostResponseNodesItem.md)[]

#### Defined in

[src/responses/insights.service.post.response.ts:60](https://github.com/Nerixyz/instagram-private-api/blob/0e0721c/src/responses/insights.service.post.response.ts#L60)

___

### value

• **value**: `number`

#### Defined in

[src/responses/insights.service.post.response.ts:59](https://github.com/Nerixyz/instagram-private-api/blob/0e0721c/src/responses/insights.service.post.response.ts#L59)
