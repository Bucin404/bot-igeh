[instagram-private-api](../../README.md) / [index](../../modules/index.md) / IgtvChannelFeedResponseIgtv_first_frame

# Interface: IgtvChannelFeedResponseIgtv\_first\_frame

[index](../../modules/index.md).IgtvChannelFeedResponseIgtv_first_frame

## Table of contents

### Properties

- [height](IgtvChannelFeedResponseIgtv_first_frame.md#height)
- [url](IgtvChannelFeedResponseIgtv_first_frame.md#url)
- [width](IgtvChannelFeedResponseIgtv_first_frame.md#width)

## Properties

### height

• **height**: `number`

#### Defined in

[src/responses/igtv.channel.feed.response.ts:72](https://github.com/Nerixyz/instagram-private-api/blob/0e0721c/src/responses/igtv.channel.feed.response.ts#L72)

___

### url

• **url**: `string`

#### Defined in

[src/responses/igtv.channel.feed.response.ts:73](https://github.com/Nerixyz/instagram-private-api/blob/0e0721c/src/responses/igtv.channel.feed.response.ts#L73)

___

### width

• **width**: `number`

#### Defined in

[src/responses/igtv.channel.feed.response.ts:71](https://github.com/Nerixyz/instagram-private-api/blob/0e0721c/src/responses/igtv.channel.feed.response.ts#L71)
