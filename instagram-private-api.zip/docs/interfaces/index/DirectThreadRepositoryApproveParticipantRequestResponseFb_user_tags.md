[instagram-private-api](../../README.md) / [index](../../modules/index.md) / DirectThreadRepositoryApproveParticipantRequestResponseFb_user_tags

# Interface: DirectThreadRepositoryApproveParticipantRequestResponseFb\_user\_tags

[index](../../modules/index.md).DirectThreadRepositoryApproveParticipantRequestResponseFb_user_tags

## Table of contents

### Properties

- [in](DirectThreadRepositoryApproveParticipantRequestResponseFb_user_tags.md#in)

## Properties

### in

• **in**: `any`[]

#### Defined in

[src/responses/direct-thread.repository.approve-participant-request.response.ts:138](https://github.com/Nerixyz/instagram-private-api/blob/0e0721c/src/responses/direct-thread.repository.approve-participant-request.response.ts#L138)
