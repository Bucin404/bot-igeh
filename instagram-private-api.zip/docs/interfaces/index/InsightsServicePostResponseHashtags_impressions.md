[instagram-private-api](../../README.md) / [index](../../modules/index.md) / InsightsServicePostResponseHashtags_impressions

# Interface: InsightsServicePostResponseHashtags\_impressions

[index](../../modules/index.md).InsightsServicePostResponseHashtags_impressions

## Table of contents

### Properties

- [hashtags](InsightsServicePostResponseHashtags_impressions.md#hashtags)
- [organic](InsightsServicePostResponseHashtags_impressions.md#organic)

## Properties

### hashtags

• **hashtags**: [`InsightsServicePostResponseHashtags`](InsightsServicePostResponseHashtags.md)

#### Defined in

[src/responses/insights.service.post.response.ts:85](https://github.com/Nerixyz/instagram-private-api/blob/0e0721c/src/responses/insights.service.post.response.ts#L85)

___

### organic

• **organic**: [`InsightsServicePostResponseOrganic`](InsightsServicePostResponseOrganic.md)

#### Defined in

[src/responses/insights.service.post.response.ts:84](https://github.com/Nerixyz/instagram-private-api/blob/0e0721c/src/responses/insights.service.post.response.ts#L84)
