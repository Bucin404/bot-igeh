[instagram-private-api](../../README.md) / [index](../../modules/index.md) / LocationFeedResponseMediasItem

# Interface: LocationFeedResponseMediasItem

[index](../../modules/index.md).LocationFeedResponseMediasItem

## Table of contents

### Properties

- [media](LocationFeedResponseMediasItem.md#media)

## Properties

### media

• **media**: [`LocationFeedResponseMedia`](LocationFeedResponseMedia.md)

#### Defined in

[src/responses/location.feed.response.ts:19](https://github.com/Nerixyz/instagram-private-api/blob/0e0721c/src/responses/location.feed.response.ts#L19)
