[instagram-private-api](../../README.md) / [index](../../modules/index.md) / InsightsServiceAccountResponseDaysHourlyFollowersGraphsItem

# Interface: InsightsServiceAccountResponseDaysHourlyFollowersGraphsItem

[index](../../modules/index.md).InsightsServiceAccountResponseDaysHourlyFollowersGraphsItem

## Table of contents

### Properties

- [data\_points](InsightsServiceAccountResponseDaysHourlyFollowersGraphsItem.md#data_points)
- [name](InsightsServiceAccountResponseDaysHourlyFollowersGraphsItem.md#name)

## Properties

### data\_points

• **data\_points**: [`InsightsServiceAccountResponseDataPointsItem`](InsightsServiceAccountResponseDataPointsItem.md)[]

#### Defined in

[src/responses/insights.service.account.response.ts:141](https://github.com/Nerixyz/instagram-private-api/blob/0e0721c/src/responses/insights.service.account.response.ts#L141)

___

### name

• **name**: `string`

#### Defined in

[src/responses/insights.service.account.response.ts:140](https://github.com/Nerixyz/instagram-private-api/blob/0e0721c/src/responses/insights.service.account.response.ts#L140)
