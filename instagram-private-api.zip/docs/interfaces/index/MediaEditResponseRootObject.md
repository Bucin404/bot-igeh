[instagram-private-api](../../README.md) / [index](../../modules/index.md) / MediaEditResponseRootObject

# Interface: MediaEditResponseRootObject

[index](../../modules/index.md).MediaEditResponseRootObject

## Table of contents

### Properties

- [media](MediaEditResponseRootObject.md#media)
- [status](MediaEditResponseRootObject.md#status)

## Properties

### media

• **media**: [`MediaInfoResponseItemsItem`](MediaInfoResponseItemsItem.md)

#### Defined in

[src/responses/media.repository.info.response.ts:83](https://github.com/Nerixyz/instagram-private-api/blob/0e0721c/src/responses/media.repository.info.response.ts#L83)

___

### status

• **status**: `string`

#### Defined in

[src/responses/media.repository.info.response.ts:84](https://github.com/Nerixyz/instagram-private-api/blob/0e0721c/src/responses/media.repository.info.response.ts#L84)
