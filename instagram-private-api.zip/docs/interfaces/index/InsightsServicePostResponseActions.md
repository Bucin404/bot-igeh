[instagram-private-api](../../README.md) / [index](../../modules/index.md) / InsightsServicePostResponseActions

# Interface: InsightsServicePostResponseActions

[index](../../modules/index.md).InsightsServicePostResponseActions

## Table of contents

### Properties

- [nodes](InsightsServicePostResponseActions.md#nodes)
- [value](InsightsServicePostResponseActions.md#value)

## Properties

### nodes

• **nodes**: [`InsightsServicePostResponseNodesItem`](InsightsServicePostResponseNodesItem.md)[]

#### Defined in

[src/responses/insights.service.post.response.ts:67](https://github.com/Nerixyz/instagram-private-api/blob/0e0721c/src/responses/insights.service.post.response.ts#L67)

___

### value

• **value**: `number`

#### Defined in

[src/responses/insights.service.post.response.ts:66](https://github.com/Nerixyz/instagram-private-api/blob/0e0721c/src/responses/insights.service.post.response.ts#L66)
