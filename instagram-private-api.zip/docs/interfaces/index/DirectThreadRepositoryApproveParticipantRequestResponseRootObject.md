[instagram-private-api](../../README.md) / [index](../../modules/index.md) / DirectThreadRepositoryApproveParticipantRequestResponseRootObject

# Interface: DirectThreadRepositoryApproveParticipantRequestResponseRootObject

[index](../../modules/index.md).DirectThreadRepositoryApproveParticipantRequestResponseRootObject

## Table of contents

### Properties

- [status](DirectThreadRepositoryApproveParticipantRequestResponseRootObject.md#status)
- [thread](DirectThreadRepositoryApproveParticipantRequestResponseRootObject.md#thread)

## Properties

### status

• **status**: `string`

#### Defined in

[src/responses/direct-thread.repository.approve-participant-request.response.ts:3](https://github.com/Nerixyz/instagram-private-api/blob/0e0721c/src/responses/direct-thread.repository.approve-participant-request.response.ts#L3)

___

### thread

• **thread**: [`DirectThreadRepositoryApproveParticipantRequestResponseThread`](DirectThreadRepositoryApproveParticipantRequestResponseThread.md)

#### Defined in

[src/responses/direct-thread.repository.approve-participant-request.response.ts:2](https://github.com/Nerixyz/instagram-private-api/blob/0e0721c/src/responses/direct-thread.repository.approve-participant-request.response.ts#L2)
