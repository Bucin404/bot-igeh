[instagram-private-api](../../README.md) / [index](../../modules/index.md) / DiscoverFeedResponseNew_suggested_users

# Interface: DiscoverFeedResponseNew\_suggested\_users

[index](../../modules/index.md).DiscoverFeedResponseNew_suggested_users

## Table of contents

### Properties

- [suggestions](DiscoverFeedResponseNew_suggested_users.md#suggestions)

## Properties

### suggestions

• **suggestions**: `any`[]

#### Defined in

[src/responses/discover.feed.response.ts:40](https://github.com/Nerixyz/instagram-private-api/blob/0e0721c/src/responses/discover.feed.response.ts#L40)
