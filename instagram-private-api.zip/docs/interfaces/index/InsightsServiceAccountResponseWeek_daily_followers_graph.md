[instagram-private-api](../../README.md) / [index](../../modules/index.md) / InsightsServiceAccountResponseWeek_daily_followers_graph

# Interface: InsightsServiceAccountResponseWeek\_daily\_followers\_graph

[index](../../modules/index.md).InsightsServiceAccountResponseWeek_daily_followers_graph

## Table of contents

### Properties

- [data\_points](InsightsServiceAccountResponseWeek_daily_followers_graph.md#data_points)

## Properties

### data\_points

• **data\_points**: [`InsightsServiceAccountResponseDataPointsItem`](InsightsServiceAccountResponseDataPointsItem.md)[]

#### Defined in

[src/responses/insights.service.account.response.ts:137](https://github.com/Nerixyz/instagram-private-api/blob/0e0721c/src/responses/insights.service.account.response.ts#L137)
