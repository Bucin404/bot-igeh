[instagram-private-api](../../README.md) / [index](../../modules/index.md) / InsightsServiceAccountResponseFollowers_top_cities_graph

# Interface: InsightsServiceAccountResponseFollowers\_top\_cities\_graph

[index](../../modules/index.md).InsightsServiceAccountResponseFollowers_top_cities_graph

## Table of contents

### Properties

- [data\_points](InsightsServiceAccountResponseFollowers_top_cities_graph.md#data_points)

## Properties

### data\_points

• **data\_points**: [`InsightsServiceAccountResponseDataPointsItem`](InsightsServiceAccountResponseDataPointsItem.md)[]

#### Defined in

[src/responses/insights.service.account.response.ts:131](https://github.com/Nerixyz/instagram-private-api/blob/0e0721c/src/responses/insights.service.account.response.ts#L131)
