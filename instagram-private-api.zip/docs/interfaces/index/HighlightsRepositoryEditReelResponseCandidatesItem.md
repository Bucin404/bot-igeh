[instagram-private-api](../../README.md) / [index](../../modules/index.md) / HighlightsRepositoryEditReelResponseCandidatesItem

# Interface: HighlightsRepositoryEditReelResponseCandidatesItem

[index](../../modules/index.md).HighlightsRepositoryEditReelResponseCandidatesItem

## Table of contents

### Properties

- [estimated\_scans\_sizes](HighlightsRepositoryEditReelResponseCandidatesItem.md#estimated_scans_sizes)
- [height](HighlightsRepositoryEditReelResponseCandidatesItem.md#height)
- [url](HighlightsRepositoryEditReelResponseCandidatesItem.md#url)
- [width](HighlightsRepositoryEditReelResponseCandidatesItem.md#width)

## Properties

### estimated\_scans\_sizes

• **estimated\_scans\_sizes**: `number`[]

#### Defined in

[src/responses/highlights.repository.edit-reel.response.ts:114](https://github.com/Nerixyz/instagram-private-api/blob/0e0721c/src/responses/highlights.repository.edit-reel.response.ts#L114)

___

### height

• **height**: `number`

#### Defined in

[src/responses/highlights.repository.edit-reel.response.ts:112](https://github.com/Nerixyz/instagram-private-api/blob/0e0721c/src/responses/highlights.repository.edit-reel.response.ts#L112)

___

### url

• **url**: `string`

#### Defined in

[src/responses/highlights.repository.edit-reel.response.ts:113](https://github.com/Nerixyz/instagram-private-api/blob/0e0721c/src/responses/highlights.repository.edit-reel.response.ts#L113)

___

### width

• **width**: `number`

#### Defined in

[src/responses/highlights.repository.edit-reel.response.ts:111](https://github.com/Nerixyz/instagram-private-api/blob/0e0721c/src/responses/highlights.repository.edit-reel.response.ts#L111)
