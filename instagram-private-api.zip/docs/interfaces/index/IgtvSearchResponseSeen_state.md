[instagram-private-api](../../README.md) / [index](../../modules/index.md) / IgtvSearchResponseSeen_state

# Interface: IgtvSearchResponseSeen\_state

[index](../../modules/index.md).IgtvSearchResponseSeen_state
