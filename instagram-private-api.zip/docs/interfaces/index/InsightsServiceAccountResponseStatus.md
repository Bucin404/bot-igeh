[instagram-private-api](../../README.md) / [index](../../modules/index.md) / InsightsServiceAccountResponseStatus

# Interface: InsightsServiceAccountResponseStatus

[index](../../modules/index.md).InsightsServiceAccountResponseStatus

## Table of contents

### Properties

- [account\_type](InsightsServiceAccountResponseStatus.md#account_type)

## Properties

### account\_type

• **account\_type**: `string`

#### Defined in

[src/responses/insights.service.account.response.ts:104](https://github.com/Nerixyz/instagram-private-api/blob/0e0721c/src/responses/insights.service.account.response.ts#L104)
