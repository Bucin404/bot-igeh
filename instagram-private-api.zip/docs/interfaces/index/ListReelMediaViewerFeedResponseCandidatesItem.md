[instagram-private-api](../../README.md) / [index](../../modules/index.md) / ListReelMediaViewerFeedResponseCandidatesItem

# Interface: ListReelMediaViewerFeedResponseCandidatesItem

[index](../../modules/index.md).ListReelMediaViewerFeedResponseCandidatesItem

## Table of contents

### Properties

- [estimated\_scans\_sizes](ListReelMediaViewerFeedResponseCandidatesItem.md#estimated_scans_sizes)
- [height](ListReelMediaViewerFeedResponseCandidatesItem.md#height)
- [url](ListReelMediaViewerFeedResponseCandidatesItem.md#url)
- [width](ListReelMediaViewerFeedResponseCandidatesItem.md#width)

## Properties

### estimated\_scans\_sizes

• **estimated\_scans\_sizes**: `number`[]

#### Defined in

[src/responses/list-reel-media-viewer.feed.response.ts:79](https://github.com/Nerixyz/instagram-private-api/blob/0e0721c/src/responses/list-reel-media-viewer.feed.response.ts#L79)

___

### height

• **height**: `number`

#### Defined in

[src/responses/list-reel-media-viewer.feed.response.ts:77](https://github.com/Nerixyz/instagram-private-api/blob/0e0721c/src/responses/list-reel-media-viewer.feed.response.ts#L77)

___

### url

• **url**: `string`

#### Defined in

[src/responses/list-reel-media-viewer.feed.response.ts:78](https://github.com/Nerixyz/instagram-private-api/blob/0e0721c/src/responses/list-reel-media-viewer.feed.response.ts#L78)

___

### width

• **width**: `number`

#### Defined in

[src/responses/list-reel-media-viewer.feed.response.ts:76](https://github.com/Nerixyz/instagram-private-api/blob/0e0721c/src/responses/list-reel-media-viewer.feed.response.ts#L76)
