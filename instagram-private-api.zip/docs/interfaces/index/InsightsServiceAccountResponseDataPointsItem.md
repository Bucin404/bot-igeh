[instagram-private-api](../../README.md) / [index](../../modules/index.md) / InsightsServiceAccountResponseDataPointsItem

# Interface: InsightsServiceAccountResponseDataPointsItem

[index](../../modules/index.md).InsightsServiceAccountResponseDataPointsItem

## Table of contents

### Properties

- [label](InsightsServiceAccountResponseDataPointsItem.md#label)
- [value](InsightsServiceAccountResponseDataPointsItem.md#value)

## Properties

### label

• **label**: `string`

#### Defined in

[src/responses/insights.service.account.response.ts:64](https://github.com/Nerixyz/instagram-private-api/blob/0e0721c/src/responses/insights.service.account.response.ts#L64)

___

### value

• **value**: `number`

#### Defined in

[src/responses/insights.service.account.response.ts:65](https://github.com/Nerixyz/instagram-private-api/blob/0e0721c/src/responses/insights.service.account.response.ts#L65)
