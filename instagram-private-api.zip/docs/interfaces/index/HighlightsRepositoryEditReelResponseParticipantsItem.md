[instagram-private-api](../../README.md) / [index](../../modules/index.md) / HighlightsRepositoryEditReelResponseParticipantsItem

# Interface: HighlightsRepositoryEditReelResponseParticipantsItem

[index](../../modules/index.md).HighlightsRepositoryEditReelResponseParticipantsItem

## Table of contents

### Properties

- [answer](HighlightsRepositoryEditReelResponseParticipantsItem.md#answer)
- [ts](HighlightsRepositoryEditReelResponseParticipantsItem.md#ts)
- [user](HighlightsRepositoryEditReelResponseParticipantsItem.md#user)

## Properties

### answer

• **answer**: `number`

#### Defined in

[src/responses/highlights.repository.edit-reel.response.ts:160](https://github.com/Nerixyz/instagram-private-api/blob/0e0721c/src/responses/highlights.repository.edit-reel.response.ts#L160)

___

### ts

• **ts**: `number`

#### Defined in

[src/responses/highlights.repository.edit-reel.response.ts:161](https://github.com/Nerixyz/instagram-private-api/blob/0e0721c/src/responses/highlights.repository.edit-reel.response.ts#L161)

___

### user

• **user**: [`HighlightsRepositoryEditReelResponseUser`](HighlightsRepositoryEditReelResponseUser.md)

#### Defined in

[src/responses/highlights.repository.edit-reel.response.ts:159](https://github.com/Nerixyz/instagram-private-api/blob/0e0721c/src/responses/highlights.repository.edit-reel.response.ts#L159)
