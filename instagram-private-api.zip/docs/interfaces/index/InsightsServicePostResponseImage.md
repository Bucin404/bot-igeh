[instagram-private-api](../../README.md) / [index](../../modules/index.md) / InsightsServicePostResponseImage

# Interface: InsightsServicePostResponseImage

[index](../../modules/index.md).InsightsServicePostResponseImage

## Table of contents

### Properties

- [height](InsightsServicePostResponseImage.md#height)
- [width](InsightsServicePostResponseImage.md#width)

## Properties

### height

• **height**: `number`

#### Defined in

[src/responses/insights.service.post.response.ts:96](https://github.com/Nerixyz/instagram-private-api/blob/0e0721c/src/responses/insights.service.post.response.ts#L96)

___

### width

• **width**: `number`

#### Defined in

[src/responses/insights.service.post.response.ts:97](https://github.com/Nerixyz/instagram-private-api/blob/0e0721c/src/responses/insights.service.post.response.ts#L97)
