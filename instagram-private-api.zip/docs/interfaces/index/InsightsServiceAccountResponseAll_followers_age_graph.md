[instagram-private-api](../../README.md) / [index](../../modules/index.md) / InsightsServiceAccountResponseAll_followers_age_graph

# Interface: InsightsServiceAccountResponseAll\_followers\_age\_graph

[index](../../modules/index.md).InsightsServiceAccountResponseAll_followers_age_graph

## Table of contents

### Properties

- [data\_points](InsightsServiceAccountResponseAll_followers_age_graph.md#data_points)

## Properties

### data\_points

• **data\_points**: [`InsightsServiceAccountResponseDataPointsItem`](InsightsServiceAccountResponseDataPointsItem.md)[]

#### Defined in

[src/responses/insights.service.account.response.ts:122](https://github.com/Nerixyz/instagram-private-api/blob/0e0721c/src/responses/insights.service.account.response.ts#L122)
