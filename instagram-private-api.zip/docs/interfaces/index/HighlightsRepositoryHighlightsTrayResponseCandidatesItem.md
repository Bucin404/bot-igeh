[instagram-private-api](../../README.md) / [index](../../modules/index.md) / HighlightsRepositoryHighlightsTrayResponseCandidatesItem

# Interface: HighlightsRepositoryHighlightsTrayResponseCandidatesItem

[index](../../modules/index.md).HighlightsRepositoryHighlightsTrayResponseCandidatesItem

## Table of contents

### Properties

- [estimated\_scans\_sizes](HighlightsRepositoryHighlightsTrayResponseCandidatesItem.md#estimated_scans_sizes)
- [height](HighlightsRepositoryHighlightsTrayResponseCandidatesItem.md#height)
- [url](HighlightsRepositoryHighlightsTrayResponseCandidatesItem.md#url)
- [width](HighlightsRepositoryHighlightsTrayResponseCandidatesItem.md#width)

## Properties

### estimated\_scans\_sizes

• **estimated\_scans\_sizes**: `number`[]

#### Defined in

[src/responses/highlights.repository.highlights-tray.response.ts:108](https://github.com/Nerixyz/instagram-private-api/blob/0e0721c/src/responses/highlights.repository.highlights-tray.response.ts#L108)

___

### height

• **height**: `number`

#### Defined in

[src/responses/highlights.repository.highlights-tray.response.ts:106](https://github.com/Nerixyz/instagram-private-api/blob/0e0721c/src/responses/highlights.repository.highlights-tray.response.ts#L106)

___

### url

• **url**: `string`

#### Defined in

[src/responses/highlights.repository.highlights-tray.response.ts:107](https://github.com/Nerixyz/instagram-private-api/blob/0e0721c/src/responses/highlights.repository.highlights-tray.response.ts#L107)

___

### width

• **width**: `number`

#### Defined in

[src/responses/highlights.repository.highlights-tray.response.ts:105](https://github.com/Nerixyz/instagram-private-api/blob/0e0721c/src/responses/highlights.repository.highlights-tray.response.ts#L105)
