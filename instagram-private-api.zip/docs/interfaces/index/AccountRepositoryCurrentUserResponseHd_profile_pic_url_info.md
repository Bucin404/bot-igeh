[instagram-private-api](../../README.md) / [index](../../modules/index.md) / AccountRepositoryCurrentUserResponseHd_profile_pic_url_info

# Interface: AccountRepositoryCurrentUserResponseHd\_profile\_pic\_url\_info

[index](../../modules/index.md).AccountRepositoryCurrentUserResponseHd_profile_pic_url_info

## Table of contents

### Properties

- [height](AccountRepositoryCurrentUserResponseHd_profile_pic_url_info.md#height)
- [url](AccountRepositoryCurrentUserResponseHd_profile_pic_url_info.md#url)
- [width](AccountRepositoryCurrentUserResponseHd_profile_pic_url_info.md#width)

## Properties

### height

• **height**: `number`

#### Defined in

[src/responses/account.repository.current-user.response.ts:43](https://github.com/Nerixyz/instagram-private-api/blob/0e0721c/src/responses/account.repository.current-user.response.ts#L43)

___

### url

• **url**: `string`

#### Defined in

[src/responses/account.repository.current-user.response.ts:41](https://github.com/Nerixyz/instagram-private-api/blob/0e0721c/src/responses/account.repository.current-user.response.ts#L41)

___

### width

• **width**: `number`

#### Defined in

[src/responses/account.repository.current-user.response.ts:42](https://github.com/Nerixyz/instagram-private-api/blob/0e0721c/src/responses/account.repository.current-user.response.ts#L42)
