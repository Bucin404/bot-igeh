[instagram-private-api](../../README.md) / [index](../../modules/index.md) / IgtvBrowseFeedResponseIgtv_first_frame

# Interface: IgtvBrowseFeedResponseIgtv\_first\_frame

[index](../../modules/index.md).IgtvBrowseFeedResponseIgtv_first_frame

## Table of contents

### Properties

- [height](IgtvBrowseFeedResponseIgtv_first_frame.md#height)
- [url](IgtvBrowseFeedResponseIgtv_first_frame.md#url)
- [width](IgtvBrowseFeedResponseIgtv_first_frame.md#width)

## Properties

### height

• **height**: `number`

#### Defined in

[src/responses/igtv.browse.feed.response.ts:138](https://github.com/Nerixyz/instagram-private-api/blob/0e0721c/src/responses/igtv.browse.feed.response.ts#L138)

___

### url

• **url**: `string`

#### Defined in

[src/responses/igtv.browse.feed.response.ts:139](https://github.com/Nerixyz/instagram-private-api/blob/0e0721c/src/responses/igtv.browse.feed.response.ts#L139)

___

### width

• **width**: `number`

#### Defined in

[src/responses/igtv.browse.feed.response.ts:137](https://github.com/Nerixyz/instagram-private-api/blob/0e0721c/src/responses/igtv.browse.feed.response.ts#L137)
