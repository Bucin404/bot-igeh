[instagram-private-api](../../README.md) / [index](../../modules/index.md) / IgtvBrowseFeedResponseBadging

# Interface: IgtvBrowseFeedResponseBadging

[index](../../modules/index.md).IgtvBrowseFeedResponseBadging

## Table of contents

### Properties

- [ids](IgtvBrowseFeedResponseBadging.md#ids)
- [items](IgtvBrowseFeedResponseBadging.md#items)

## Properties

### ids

• **ids**: `any`[]

#### Defined in

[src/responses/igtv.browse.feed.response.ts:14](https://github.com/Nerixyz/instagram-private-api/blob/0e0721c/src/responses/igtv.browse.feed.response.ts#L14)

___

### items

• **items**: `any`[]

#### Defined in

[src/responses/igtv.browse.feed.response.ts:15](https://github.com/Nerixyz/instagram-private-api/blob/0e0721c/src/responses/igtv.browse.feed.response.ts#L15)
