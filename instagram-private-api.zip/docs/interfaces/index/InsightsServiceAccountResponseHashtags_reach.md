[instagram-private-api](../../README.md) / [index](../../modules/index.md) / InsightsServiceAccountResponseHashtags_reach

# Interface: InsightsServiceAccountResponseHashtags\_reach

[index](../../modules/index.md).InsightsServiceAccountResponseHashtags_reach

## Table of contents

### Properties

- [follow\_status](InsightsServiceAccountResponseHashtags_reach.md#follow_status)
- [name](InsightsServiceAccountResponseHashtags_reach.md#name)

## Properties

### follow\_status

• **follow\_status**: [`InsightsServiceAccountResponseFollow_status`](InsightsServiceAccountResponseFollow_status.md)

#### Defined in

[src/responses/insights.service.account.response.ts:80](https://github.com/Nerixyz/instagram-private-api/blob/0e0721c/src/responses/insights.service.account.response.ts#L80)

___

### name

• **name**: `string`

#### Defined in

[src/responses/insights.service.account.response.ts:79](https://github.com/Nerixyz/instagram-private-api/blob/0e0721c/src/responses/insights.service.account.response.ts#L79)
