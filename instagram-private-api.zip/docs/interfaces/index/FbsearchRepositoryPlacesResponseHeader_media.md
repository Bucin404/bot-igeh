[instagram-private-api](../../README.md) / [index](../../modules/index.md) / FbsearchRepositoryPlacesResponseHeader_media

# Interface: FbsearchRepositoryPlacesResponseHeader\_media

[index](../../modules/index.md).FbsearchRepositoryPlacesResponseHeader_media
