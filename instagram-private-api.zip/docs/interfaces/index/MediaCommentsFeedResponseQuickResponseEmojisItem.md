[instagram-private-api](../../README.md) / [index](../../modules/index.md) / MediaCommentsFeedResponseQuickResponseEmojisItem

# Interface: MediaCommentsFeedResponseQuickResponseEmojisItem

[index](../../modules/index.md).MediaCommentsFeedResponseQuickResponseEmojisItem

## Table of contents

### Properties

- [unicode](MediaCommentsFeedResponseQuickResponseEmojisItem.md#unicode)

## Properties

### unicode

• **unicode**: `string`

#### Defined in

[src/responses/media-comments.feed.response.ts:93](https://github.com/Nerixyz/instagram-private-api/blob/0e0721c/src/responses/media-comments.feed.response.ts#L93)
