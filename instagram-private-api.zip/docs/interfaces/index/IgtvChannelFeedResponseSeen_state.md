[instagram-private-api](../../README.md) / [index](../../modules/index.md) / IgtvChannelFeedResponseSeen_state

# Interface: IgtvChannelFeedResponseSeen\_state

[index](../../modules/index.md).IgtvChannelFeedResponseSeen_state
