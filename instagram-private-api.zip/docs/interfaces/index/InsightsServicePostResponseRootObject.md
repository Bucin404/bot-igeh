[instagram-private-api](../../README.md) / [index](../../modules/index.md) / InsightsServicePostResponseRootObject

# Interface: InsightsServicePostResponseRootObject

[index](../../modules/index.md).InsightsServicePostResponseRootObject

## Table of contents

### Properties

- [data](InsightsServicePostResponseRootObject.md#data)

## Properties

### data

• **data**: [`InsightsServicePostResponseData`](InsightsServicePostResponseData.md)

#### Defined in

[src/responses/insights.service.post.response.ts:2](https://github.com/Nerixyz/instagram-private-api/blob/0e0721c/src/responses/insights.service.post.response.ts#L2)
