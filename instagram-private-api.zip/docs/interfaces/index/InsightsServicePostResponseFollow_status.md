[instagram-private-api](../../README.md) / [index](../../modules/index.md) / InsightsServicePostResponseFollow_status

# Interface: InsightsServicePostResponseFollow\_status

[index](../../modules/index.md).InsightsServicePostResponseFollow_status

## Table of contents

### Properties

- [nodes](InsightsServicePostResponseFollow_status.md#nodes)

## Properties

### nodes

• **nodes**: [`InsightsServicePostResponseNodesItem`](InsightsServicePostResponseNodesItem.md)[]

#### Defined in

[src/responses/insights.service.post.response.ts:81](https://github.com/Nerixyz/instagram-private-api/blob/0e0721c/src/responses/insights.service.post.response.ts#L81)
