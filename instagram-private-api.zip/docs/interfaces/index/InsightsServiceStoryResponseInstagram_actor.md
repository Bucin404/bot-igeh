[instagram-private-api](../../README.md) / [index](../../modules/index.md) / InsightsServiceStoryResponseInstagram_actor

# Interface: InsightsServiceStoryResponseInstagram\_actor

[index](../../modules/index.md).InsightsServiceStoryResponseInstagram_actor

## Table of contents

### Properties

- [id](InsightsServiceStoryResponseInstagram_actor.md#id)
- [instagram\_actor\_id](InsightsServiceStoryResponseInstagram_actor.md#instagram_actor_id)

## Properties

### id

• **id**: `string`

#### Defined in

[src/responses/insights.service.story.response.ts:24](https://github.com/Nerixyz/instagram-private-api/blob/0e0721c/src/responses/insights.service.story.response.ts#L24)

___

### instagram\_actor\_id

• **instagram\_actor\_id**: `string`

#### Defined in

[src/responses/insights.service.story.response.ts:23](https://github.com/Nerixyz/instagram-private-api/blob/0e0721c/src/responses/insights.service.story.response.ts#L23)
