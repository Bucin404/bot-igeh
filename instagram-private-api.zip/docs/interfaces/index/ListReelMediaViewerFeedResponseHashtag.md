[instagram-private-api](../../README.md) / [index](../../modules/index.md) / ListReelMediaViewerFeedResponseHashtag

# Interface: ListReelMediaViewerFeedResponseHashtag

[index](../../modules/index.md).ListReelMediaViewerFeedResponseHashtag

## Table of contents

### Properties

- [id](ListReelMediaViewerFeedResponseHashtag.md#id)
- [name](ListReelMediaViewerFeedResponseHashtag.md#name)

## Properties

### id

• **id**: `string`

#### Defined in

[src/responses/list-reel-media-viewer.feed.response.ts:147](https://github.com/Nerixyz/instagram-private-api/blob/0e0721c/src/responses/list-reel-media-viewer.feed.response.ts#L147)

___

### name

• **name**: `string`

#### Defined in

[src/responses/list-reel-media-viewer.feed.response.ts:146](https://github.com/Nerixyz/instagram-private-api/blob/0e0721c/src/responses/list-reel-media-viewer.feed.response.ts#L146)
