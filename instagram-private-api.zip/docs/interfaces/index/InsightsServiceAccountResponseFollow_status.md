[instagram-private-api](../../README.md) / [index](../../modules/index.md) / InsightsServiceAccountResponseFollow_status

# Interface: InsightsServiceAccountResponseFollow\_status

[index](../../modules/index.md).InsightsServiceAccountResponseFollow_status

## Table of contents

### Properties

- [nodes](InsightsServiceAccountResponseFollow_status.md#nodes)

## Properties

### nodes

• **nodes**: [`InsightsServiceAccountResponseNodesItem`](InsightsServiceAccountResponseNodesItem.md)[]

#### Defined in

[src/responses/insights.service.account.response.ts:83](https://github.com/Nerixyz/instagram-private-api/blob/0e0721c/src/responses/insights.service.account.response.ts#L83)
