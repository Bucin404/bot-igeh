[instagram-private-api](../../README.md) / [index](../../modules/index.md) / DirectInboxFeedResponsePlaceholder

# Interface: DirectInboxFeedResponsePlaceholder

[index](../../modules/index.md).DirectInboxFeedResponsePlaceholder

## Table of contents

### Properties

- [is\_linked](DirectInboxFeedResponsePlaceholder.md#is_linked)
- [message](DirectInboxFeedResponsePlaceholder.md#message)
- [title](DirectInboxFeedResponsePlaceholder.md#title)

## Properties

### is\_linked

• **is\_linked**: `boolean`

#### Defined in

[src/responses/direct-inbox.feed.response.ts:159](https://github.com/Nerixyz/instagram-private-api/blob/0e0721c/src/responses/direct-inbox.feed.response.ts#L159)

___

### message

• **message**: `string`

#### Defined in

[src/responses/direct-inbox.feed.response.ts:161](https://github.com/Nerixyz/instagram-private-api/blob/0e0721c/src/responses/direct-inbox.feed.response.ts#L161)

___

### title

• **title**: `string`

#### Defined in

[src/responses/direct-inbox.feed.response.ts:160](https://github.com/Nerixyz/instagram-private-api/blob/0e0721c/src/responses/direct-inbox.feed.response.ts#L160)
