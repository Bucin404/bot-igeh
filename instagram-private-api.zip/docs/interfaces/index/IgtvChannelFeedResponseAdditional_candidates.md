[instagram-private-api](../../README.md) / [index](../../modules/index.md) / IgtvChannelFeedResponseAdditional_candidates

# Interface: IgtvChannelFeedResponseAdditional\_candidates

[index](../../modules/index.md).IgtvChannelFeedResponseAdditional_candidates

## Table of contents

### Properties

- [igtv\_first\_frame](IgtvChannelFeedResponseAdditional_candidates.md#igtv_first_frame)

## Properties

### igtv\_first\_frame

• **igtv\_first\_frame**: [`IgtvChannelFeedResponseIgtv_first_frame`](IgtvChannelFeedResponseIgtv_first_frame.md)

#### Defined in

[src/responses/igtv.channel.feed.response.ts:68](https://github.com/Nerixyz/instagram-private-api/blob/0e0721c/src/responses/igtv.channel.feed.response.ts#L68)
