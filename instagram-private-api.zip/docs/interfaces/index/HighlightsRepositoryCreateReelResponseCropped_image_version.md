[instagram-private-api](../../README.md) / [index](../../modules/index.md) / HighlightsRepositoryCreateReelResponseCropped_image_version

# Interface: HighlightsRepositoryCreateReelResponseCropped\_image\_version

[index](../../modules/index.md).HighlightsRepositoryCreateReelResponseCropped_image_version

## Table of contents

### Properties

- [estimated\_scans\_sizes](HighlightsRepositoryCreateReelResponseCropped_image_version.md#estimated_scans_sizes)
- [height](HighlightsRepositoryCreateReelResponseCropped_image_version.md#height)
- [url](HighlightsRepositoryCreateReelResponseCropped_image_version.md#url)
- [width](HighlightsRepositoryCreateReelResponseCropped_image_version.md#width)

## Properties

### estimated\_scans\_sizes

• **estimated\_scans\_sizes**: `number`[]

#### Defined in

[src/responses/highlights.repository.create-reel.response.ts:34](https://github.com/Nerixyz/instagram-private-api/blob/0e0721c/src/responses/highlights.repository.create-reel.response.ts#L34)

___

### height

• **height**: `number`

#### Defined in

[src/responses/highlights.repository.create-reel.response.ts:32](https://github.com/Nerixyz/instagram-private-api/blob/0e0721c/src/responses/highlights.repository.create-reel.response.ts#L32)

___

### url

• **url**: `string`

#### Defined in

[src/responses/highlights.repository.create-reel.response.ts:33](https://github.com/Nerixyz/instagram-private-api/blob/0e0721c/src/responses/highlights.repository.create-reel.response.ts#L33)

___

### width

• **width**: `number`

#### Defined in

[src/responses/highlights.repository.create-reel.response.ts:31](https://github.com/Nerixyz/instagram-private-api/blob/0e0721c/src/responses/highlights.repository.create-reel.response.ts#L31)
