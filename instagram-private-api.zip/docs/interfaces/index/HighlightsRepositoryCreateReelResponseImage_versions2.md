[instagram-private-api](../../README.md) / [index](../../modules/index.md) / HighlightsRepositoryCreateReelResponseImage_versions2

# Interface: HighlightsRepositoryCreateReelResponseImage\_versions2

[index](../../modules/index.md).HighlightsRepositoryCreateReelResponseImage_versions2

## Table of contents

### Properties

- [candidates](HighlightsRepositoryCreateReelResponseImage_versions2.md#candidates)

## Properties

### candidates

• **candidates**: [`HighlightsRepositoryCreateReelResponseCandidatesItem`](HighlightsRepositoryCreateReelResponseCandidatesItem.md)[]

#### Defined in

[src/responses/highlights.repository.create-reel.response.ts:104](https://github.com/Nerixyz/instagram-private-api/blob/0e0721c/src/responses/highlights.repository.create-reel.response.ts#L104)
