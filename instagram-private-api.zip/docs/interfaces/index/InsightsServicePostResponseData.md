[instagram-private-api](../../README.md) / [index](../../modules/index.md) / InsightsServicePostResponseData

# Interface: InsightsServicePostResponseData

[index](../../modules/index.md).InsightsServicePostResponseData

## Table of contents

### Properties

- [media](InsightsServicePostResponseData.md#media)

## Properties

### media

• **media**: [`InsightsServicePostResponseMedia`](InsightsServicePostResponseMedia.md)

#### Defined in

[src/responses/insights.service.post.response.ts:5](https://github.com/Nerixyz/instagram-private-api/blob/0e0721c/src/responses/insights.service.post.response.ts#L5)
