[instagram-private-api](../../README.md) / [index](../../modules/index.md) / DirectThreadRepositoryApproveParticipantRequestResponseImage_versions2

# Interface: DirectThreadRepositoryApproveParticipantRequestResponseImage\_versions2

[index](../../modules/index.md).DirectThreadRepositoryApproveParticipantRequestResponseImage_versions2

## Table of contents

### Properties

- [candidates](DirectThreadRepositoryApproveParticipantRequestResponseImage_versions2.md#candidates)

## Properties

### candidates

• **candidates**: [`DirectThreadRepositoryApproveParticipantRequestResponseCandidatesItem`](DirectThreadRepositoryApproveParticipantRequestResponseCandidatesItem.md)[]

#### Defined in

[src/responses/direct-thread.repository.approve-participant-request.response.ts:114](https://github.com/Nerixyz/instagram-private-api/blob/0e0721c/src/responses/direct-thread.repository.approve-participant-request.response.ts#L114)
