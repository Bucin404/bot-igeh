[instagram-private-api](../../README.md) / [index](../../modules/index.md) / ListReelMediaViewerFeedResponseImage_versions2

# Interface: ListReelMediaViewerFeedResponseImage\_versions2

[index](../../modules/index.md).ListReelMediaViewerFeedResponseImage_versions2

## Table of contents

### Properties

- [candidates](ListReelMediaViewerFeedResponseImage_versions2.md#candidates)

## Properties

### candidates

• **candidates**: [`ListReelMediaViewerFeedResponseCandidatesItem`](ListReelMediaViewerFeedResponseCandidatesItem.md)[]

#### Defined in

[src/responses/list-reel-media-viewer.feed.response.ts:73](https://github.com/Nerixyz/instagram-private-api/blob/0e0721c/src/responses/list-reel-media-viewer.feed.response.ts#L73)
