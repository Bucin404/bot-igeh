[instagram-private-api](../../README.md) / [index](../../modules/index.md) / AccountRepositoryLoginResponseRootObject

# Interface: AccountRepositoryLoginResponseRootObject

[index](../../modules/index.md).AccountRepositoryLoginResponseRootObject

## Table of contents

### Properties

- [logged\_in\_user](AccountRepositoryLoginResponseRootObject.md#logged_in_user)
- [status](AccountRepositoryLoginResponseRootObject.md#status)

## Properties

### logged\_in\_user

• **logged\_in\_user**: [`AccountRepositoryLoginResponseLogged_in_user`](AccountRepositoryLoginResponseLogged_in_user.md)

#### Defined in

[src/responses/account.repository.login.response.ts:2](https://github.com/Nerixyz/instagram-private-api/blob/0e0721c/src/responses/account.repository.login.response.ts#L2)

___

### status

• **status**: `string`

#### Defined in

[src/responses/account.repository.login.response.ts:3](https://github.com/Nerixyz/instagram-private-api/blob/0e0721c/src/responses/account.repository.login.response.ts#L3)
