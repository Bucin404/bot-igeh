[instagram-private-api](../../README.md) / [index](../../modules/index.md) / InsightsServiceAccountResponseRootObject

# Interface: InsightsServiceAccountResponseRootObject

[index](../../modules/index.md).InsightsServiceAccountResponseRootObject

## Table of contents

### Properties

- [data](InsightsServiceAccountResponseRootObject.md#data)

## Properties

### data

• **data**: [`InsightsServiceAccountResponseData`](InsightsServiceAccountResponseData.md)

#### Defined in

[src/responses/insights.service.account.response.ts:2](https://github.com/Nerixyz/instagram-private-api/blob/0e0721c/src/responses/insights.service.account.response.ts#L2)
