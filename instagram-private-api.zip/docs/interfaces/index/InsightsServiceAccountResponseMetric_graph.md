[instagram-private-api](../../README.md) / [index](../../modules/index.md) / InsightsServiceAccountResponseMetric_graph

# Interface: InsightsServiceAccountResponseMetric\_graph

[index](../../modules/index.md).InsightsServiceAccountResponseMetric_graph

## Table of contents

### Properties

- [nodes](InsightsServiceAccountResponseMetric_graph.md#nodes)

## Properties

### nodes

• **nodes**: [`InsightsServiceAccountResponseNodesItem`](InsightsServiceAccountResponseNodesItem.md)[]

#### Defined in

[src/responses/insights.service.account.response.ts:101](https://github.com/Nerixyz/instagram-private-api/blob/0e0721c/src/responses/insights.service.account.response.ts#L101)
