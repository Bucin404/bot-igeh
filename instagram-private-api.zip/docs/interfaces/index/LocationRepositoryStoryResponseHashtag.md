[instagram-private-api](../../README.md) / [index](../../modules/index.md) / LocationRepositoryStoryResponseHashtag

# Interface: LocationRepositoryStoryResponseHashtag

[index](../../modules/index.md).LocationRepositoryStoryResponseHashtag

## Table of contents

### Properties

- [id](LocationRepositoryStoryResponseHashtag.md#id)
- [name](LocationRepositoryStoryResponseHashtag.md#name)

## Properties

### id

• **id**: `string`

#### Defined in

[src/responses/location.repository.story.response.ts:150](https://github.com/Nerixyz/instagram-private-api/blob/0e0721c/src/responses/location.repository.story.response.ts#L150)

___

### name

• **name**: `string`

#### Defined in

[src/responses/location.repository.story.response.ts:149](https://github.com/Nerixyz/instagram-private-api/blob/0e0721c/src/responses/location.repository.story.response.ts#L149)
