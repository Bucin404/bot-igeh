[instagram-private-api](../../README.md) / [index](../../modules/index.md) / LocationFeedResponseImage_versions2

# Interface: LocationFeedResponseImage\_versions2

[index](../../modules/index.md).LocationFeedResponseImage_versions2

## Table of contents

### Properties

- [candidates](LocationFeedResponseImage_versions2.md#candidates)

## Properties

### candidates

• **candidates**: [`LocationFeedResponseCandidatesItem`](LocationFeedResponseCandidatesItem.md)[]

#### Defined in

[src/responses/location.feed.response.ts:115](https://github.com/Nerixyz/instagram-private-api/blob/0e0721c/src/responses/location.feed.response.ts#L115)
