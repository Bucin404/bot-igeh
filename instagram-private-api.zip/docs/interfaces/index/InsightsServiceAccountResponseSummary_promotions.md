[instagram-private-api](../../README.md) / [index](../../modules/index.md) / InsightsServiceAccountResponseSummary_promotions

# Interface: InsightsServiceAccountResponseSummary\_promotions

[index](../../modules/index.md).InsightsServiceAccountResponseSummary_promotions

## Table of contents

### Properties

- [edges](InsightsServiceAccountResponseSummary_promotions.md#edges)

## Properties

### edges

• **edges**: `any`[]

#### Defined in

[src/responses/insights.service.account.response.ts:168](https://github.com/Nerixyz/instagram-private-api/blob/0e0721c/src/responses/insights.service.account.response.ts#L168)
