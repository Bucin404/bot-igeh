import { zip } from "./index";
export = zip;
