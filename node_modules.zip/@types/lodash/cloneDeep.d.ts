import { cloneDeep } from "./index";
export = cloneDeep;
