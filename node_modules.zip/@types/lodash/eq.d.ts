import { eq } from "./index";
export = eq;
