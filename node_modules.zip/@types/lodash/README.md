# Installation
> `npm install --save @types/lodash`

# Summary
This package contains type definitions for Lo-Dash ( https://lodash.com ).

# Details
Files were exported from https://github.com/DefinitelyTyped/DefinitelyTyped/tree/master/types/lodash

Additional Details
 * Last updated: Mon, 11 Mar 2019 22:35:33 GMT
 * Dependencies: none
 * Global values: _

# Credits
These definitions were written by Brian Zengel <https://github.com/bczengel>, Ilya Mochalov <https://github.com/chrootsu>, Stepan Mikhaylyuk <https://github.com/stepancar>, AJ Richardson <https://github.com/aj-r>, Junyoung Clare Jang <https://github.com/ailrun>, e-cloud <https://github.com/e-cloud>, Georgii Dolzhykov <https://github.com/thorn0>, Jack Moore <https://github.com/jtmthf>, Dominique Rau <https://github.com/DomiR>.
