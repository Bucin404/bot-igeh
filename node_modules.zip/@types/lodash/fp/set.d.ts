import { set } from "../fp";
export = set;
