import { symmetricDifference } from "../fp";
export = symmetricDifference;
