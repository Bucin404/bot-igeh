import { isEqualWith } from "../fp";
export = isEqualWith;
