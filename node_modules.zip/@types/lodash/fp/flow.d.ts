import { flow } from "../fp";
export = flow;
