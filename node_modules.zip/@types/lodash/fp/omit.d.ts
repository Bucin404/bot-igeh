import { omit } from "../fp";
export = omit;
