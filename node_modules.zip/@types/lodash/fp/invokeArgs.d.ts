import { invokeArgs } from "../fp";
export = invokeArgs;
