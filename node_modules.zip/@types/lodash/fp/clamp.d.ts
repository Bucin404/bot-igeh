import { clamp } from "../fp";
export = clamp;
