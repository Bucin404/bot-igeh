import { without } from "../fp";
export = without;
