import { toFinite } from "../fp";
export = toFinite;
