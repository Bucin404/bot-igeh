import { invoke } from "../fp";
export = invoke;
