import { isNil } from "../fp";
export = isNil;
