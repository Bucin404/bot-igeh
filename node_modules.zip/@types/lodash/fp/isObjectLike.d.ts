import { isObjectLike } from "../fp";
export = isObjectLike;
