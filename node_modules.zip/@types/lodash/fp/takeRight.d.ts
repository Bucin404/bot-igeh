import { takeRight } from "../fp";
export = takeRight;
