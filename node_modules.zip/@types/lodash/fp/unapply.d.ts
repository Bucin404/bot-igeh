import { unapply } from "../fp";
export = unapply;
