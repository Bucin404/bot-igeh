import { xorBy } from "../fp";
export = xorBy;
