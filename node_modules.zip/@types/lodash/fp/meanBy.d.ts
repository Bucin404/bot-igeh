import { meanBy } from "../fp";
export = meanBy;
