import { indexBy } from "../fp";
export = indexBy;
