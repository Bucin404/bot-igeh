import { findIndexFrom } from "../fp";
export = findIndexFrom;
