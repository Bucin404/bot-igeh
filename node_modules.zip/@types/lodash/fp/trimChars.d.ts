import { trimChars } from "../fp";
export = trimChars;
