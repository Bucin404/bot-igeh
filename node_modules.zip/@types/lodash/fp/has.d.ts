import { has } from "../fp";
export = has;
