import { pull } from "../fp";
export = pull;
