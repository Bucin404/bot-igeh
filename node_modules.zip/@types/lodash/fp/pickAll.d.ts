import { pickAll } from "../fp";
export = pickAll;
