import { lastIndexOf } from "../fp";
export = lastIndexOf;
