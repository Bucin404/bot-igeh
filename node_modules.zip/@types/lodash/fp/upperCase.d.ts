import { upperCase } from "../fp";
export = upperCase;
